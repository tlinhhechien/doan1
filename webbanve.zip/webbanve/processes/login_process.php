<?php
session_start();
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Nếu không tìm thấy username
        $_SESSION['error'] = "Tên đăng nhập không tồn tại!";
        header("Location: ../pages/login.php");
        exit();
    } elseif (!password_verify($password, $user['password'])) {
        // Nếu tìm thấy username nhưng password sai
        $_SESSION['error'] = "Mật khẩu không đúng!";
        header("Location: ../pages/login.php");
        exit();
    } else {
        // Nếu cả username và password đều đúng
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['success'] = "Đăng nhập thành công!";
        header("Location: ../index.php");
        exit();
    }
}
?>