<?php
// This is a simple script to create a "no image" placeholder image

$width = 400;
$height = 400;
$image = imagecreatetruecolor($width, $height);

// Colors
$grey = imagecolorallocate($image, 240, 240, 240);
$darkGrey = imagecolorallocate($image, 160, 160, 160);
$textColor = imagecolorallocate($image, 100, 100, 100);

// Fill the background
imagefill($image, 0, 0, $grey);

// Draw a border
imagerectangle($image, 0, 0, $width - 1, $height - 1, $darkGrey);

// Add text
$text = "No Image";
$font = 5; // Use a built-in font
$textWidth = imagefontwidth($font) * strlen($text);
$textHeight = imagefontheight($font);
$x = ($width - $textWidth) / 2;
$y = ($height - $textHeight) / 2;

imagestring($image, $font, $x, $y, $text, $textColor);

// Draw camera icon (simplified)
$iconSize = 80;
$iconX = ($width - $iconSize) / 2;
$iconY = $y - $iconSize - 10;

// Camera body
imagefilledrectangle($image, $iconX, $iconY + $iconSize/3, $iconX + $iconSize, $iconY + $iconSize, $darkGrey);
// Camera lens
imagefilledellipse($image, $iconX + $iconSize/2, $iconY + $iconSize/2 + $iconSize/6, $iconSize/2, $iconSize/2, $textColor);
// Camera top
imagefilledrectangle($image, $iconX + $iconSize/4, $iconY, $iconX + 3*$iconSize/4, $iconY + $iconSize/3, $darkGrey);

// Output the image
header('Content-Type: image/jpeg');
imagejpeg($image, dirname(__DIR__) . '/assets/images/no-image.jpg');
imagedestroy($image);

echo "No-image placeholder created!";
?>
