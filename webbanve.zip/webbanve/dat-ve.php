<?php
require_once 'includes/config.php';
require_once 'includes/header.php';

// Xử lý tìm kiếm
$from_station = isset($_GET['from']) ? $_GET['from'] : '';
$to_station = isset($_GET['to']) ? $_GET['to'] : '';
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Query để lấy danh sách ga
$stations_query = "SELECT * FROM gatau ORDER BY city, station_name";
$stations_stmt = $conn->query($stations_query);
$stations = $stations_stmt->fetchAll(PDO::FETCH_ASSOC);

// Query để lấy danh sách vé
$tickets_query = "SELECT t.*, 
    l.train_name, l.train_number,
    g1.station_name as departure_station, g1.city as departure_city,
    g2.station_name as arrival_station, g2.city as arrival_city
    FROM tuyenduong t
    JOIN loaitau l ON t.train_id = l.id
    JOIN gatau g1 ON t.departure_station_id = g1.id
    JOIN gatau g2 ON t.arrival_station_id = g2.id
    WHERE t.status = 'active'";

$params = [];
if (!empty($from_station)) {
    $tickets_query .= " AND t.departure_station_id = :from_station";
    $params[':from_station'] = $from_station;
}
if (!empty($to_station)) {
    $tickets_query .= " AND t.arrival_station_id = :to_station";
    $params[':to_station'] = $to_station;
}

$tickets_stmt = $conn->prepare($tickets_query);
$tickets_stmt->execute($params);
$tickets = $tickets_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mx-auto px-4 py-8">
    <!-- Form tìm kiếm -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-2xl font-bold text-[#003366] mb-4">Tìm chuyến tàu</h2>
        <form action="" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Điểm đi</label>
                <select name="from" class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50">
                    <option value="">Chọn ga đi</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>" <?php echo $from_station == $station['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Điểm đến</label>
                <select name="to" class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50">
                    <option value="">Chọn ga đến</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>" <?php echo $to_station == $station['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Ngày đi</label>
                <input type="date" name="date" value="<?php echo $date; ?>" min="<?php echo date('Y-m-d'); ?>" 
                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50">
            </div>
            <div class="flex items-end">
                <button type="submit" class="w-full bg-[#003366] text-white py-2 px-4 rounded-md hover:bg-[#002244] transition duration-300">
                    Tìm kiếm
                </button>
            </div>
        </form>
    </div>

    <!-- Danh sách vé -->
    <div class="space-y-4">
        <?php if (count($tickets) > 0): ?>
            <?php foreach ($tickets as $ticket): ?>
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
                        <div class="mb-4 md:mb-0">
                            <h3 class="text-xl font-semibold text-[#003366]"><?php echo htmlspecialchars($ticket['train_name']); ?></h3>
                            <p class="text-gray-600">Mã tàu: <?php echo htmlspecialchars($ticket['train_number']); ?></p>
                        </div>
                        <div class="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-8">
                            <div class="text-center">
                                <p class="font-semibold"><?php echo htmlspecialchars($ticket['departure_station']); ?></p>
                                <p class="text-gray-600"><?php echo htmlspecialchars($ticket['departure_city']); ?></p>
                                <p class="text-[#003366]"><?php echo date('H:i', strtotime($ticket['departure_time'])); ?></p>
                            </div>
                            <div class="hidden md:block">
                                <div class="w-32 h-0.5 bg-gray-300"></div>
                                <p class="text-center text-sm text-gray-500 mt-1">
                                    <?php 
                                    $departure = new DateTime($ticket['departure_time']);
                                    $arrival = new DateTime($ticket['arrival_time']);
                                    $interval = $departure->diff($arrival);
                                    echo $interval->format('%Hh%ip');
                                    ?>
                                </p>
                            </div>
                            <div class="text-center">
                                <p class="font-semibold"><?php echo htmlspecialchars($ticket['arrival_station']); ?></p>
                                <p class="text-gray-600"><?php echo htmlspecialchars($ticket['arrival_city']); ?></p>
                                <p class="text-[#003366]"><?php echo date('H:i', strtotime($ticket['arrival_time'])); ?></p>
                            </div>
                        </div>
                        <div class="mt-4 md:mt-0 text-center">
                            <p class="text-2xl font-bold text-[#003366]"><?php echo number_format($ticket['price'], 0, ',', '.'); ?> đ</p>
                            <a href="datve_detail.php?id=<?php echo $ticket['id']; ?>&date=<?php echo $date; ?>" 
                                class="inline-block mt-2 bg-[#003366] text-white py-2 px-6 rounded-md hover:bg-[#002244] transition duration-300">
                                Chọn
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <p class="text-gray-600">Không tìm thấy chuyến tàu phù hợp.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 