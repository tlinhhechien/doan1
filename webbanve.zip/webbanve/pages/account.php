<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$stmt = $conn->prepare("SELECT username, email, created_at FROM users WHERE id = :id");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php include '../includes/header.php'; ?>

<div class="container mx-auto px-4 py-16">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Header Section -->
            <div class="bg-[#003366] px-6 py-8 text-center">
                <div class="w-24 h-24 mx-auto mb-4 rounded-full bg-white flex items-center justify-center">
                    <i class="fas fa-user-circle text-6xl text-[#003366]"></i>
                </div>
                <h1 class="text-2xl font-bold text-white">Thông tin tài khoản</h1>
            </div>

            <!-- Account Information -->
            <div class="p-6 space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-500 mb-1">Tên đăng nhập</div>
                        <div class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($user['username']); ?></div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-500 mb-1">Email</div>
                        <div class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($user['email']); ?></div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-500 mb-1">Ngày tạo tài khoản</div>
                        <div class="text-lg font-medium text-gray-900"><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></div>
                    </div>
                </div>

                <!-- Account Actions -->
                <div class="flex flex-col sm:flex-row gap-4 mt-8">
                    <a href="doimatkhau.php" 
                       class="flex-1 bg-[#003366] text-white px-6 py-3 rounded-lg text-center font-medium hover:bg-[#002244] transition-colors duration-200">
                        <i class="fas fa-key mr-2"></i>
                        Đổi mật khẩu
                    </a>
                    <a href="processes/logout.php" 
                       class="flex-1 bg-red-600 text-white px-6 py-3 rounded-lg text-center font-medium hover:bg-red-700 transition-colors duration-200">
                        <i class="fas fa-sign-out-alt mr-2"></i>
                        Đăng xuất
                    </a>
                </div>
            </div>

            <!-- Additional Information -->
            <div class="border-t border-gray-200 p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-4">Thông tin bổ sung</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-500 mb-1">Trạng thái tài khoản</div>
                        <div class="text-green-600 font-medium">
                            <i class="fas fa-check-circle mr-2"></i>
                            Đang hoạt động
                        </div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>