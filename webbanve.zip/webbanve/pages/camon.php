<?php
require_once 'includes/config.php';
require_once 'includes/header.php';

// Tùy chọn: Lấy thông tin booking nếu cần hiển thị chi tiết trên trang cảm ơn
$booking_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$booking = null;
if ($booking_id > 0) {
    $booking_query = "SELECT d.*, 
        l.train_name, l.train_number
        FROM datve d
        JOIN tuyenduong t ON d.route_id = t.id
        JOIN loaitau l ON t.train_id = l.id
        WHERE d.id = :booking_id AND d.user_id = :user_id";
    $booking_stmt = $conn->prepare($booking_query);
    $booking_stmt->execute([
        ':booking_id' => $booking_id,
        ':user_id' => $_SESSION['user_id'] ?? 0 // Sử dụng user_id từ session, mặc định 0 nếu chưa đăng nhập
    ]);
    $booking = $booking_stmt->fetch(PDO::FETCH_ASSOC);
}

?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-md mx-auto text-center bg-white rounded-lg shadow-md p-8">
        <svg class="mx-auto mb-4 text-green-500 w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <h2 class="text-2xl font-bold text-[#003366] mb-4">Đặt vé thành công!</h2>
        <p class="text-gray-700 mb-6">Cảm ơn bạn đã đặt vé tại hệ thống của chúng tôi.</p>
        
        <?php if ($booking): ?>
            <p class="text-gray-600 mb-2">Mã đặt vé của bạn: <strong><?php echo htmlspecialchars($booking['id']); ?></strong></p>
            <p class="text-gray-600 mb-2">Chuyến tàu: <strong><?php echo htmlspecialchars($booking['train_name']); ?> (<?php echo htmlspecialchars($booking['train_number']); ?>)</strong></p>
            <p class="text-gray-600 mb-6">Số lượng vé: <strong><?php echo htmlspecialchars($booking['number_of_tickets']); ?></strong></p>
        <?php else: ?>
            <p class="text-gray-600 mb-6">Thông tin chi tiết đơn hàng đã được gửi đến email của bạn.</p>
        <?php endif; ?>

        <a href="index.php" class="bg-[#003366] text-white py-2 px-6 rounded-md hover:bg-[#002244] transition duration-300 inline-block">Trở về trang chủ</a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>