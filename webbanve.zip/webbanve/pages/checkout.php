<?php
require_once 'includes/config.php';
require_once 'includes/header.php';

// Kiểm tra đăng nhập
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Lấy thông tin đặt vé
$booking_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$booking_query = "SELECT d.*, 
    t.departure_time, t.arrival_time,
    l.train_name, l.train_number,
    g1.station_name as departure_station, g1.city as departure_city,
    g2.station_name as arrival_station, g2.city as arrival_city
    FROM datve d
    JOIN tuyenduong t ON d.route_id = t.id
    JOIN loaitau l ON t.train_id = l.id
    JOIN gatau g1 ON t.departure_station_id = g1.id
    JOIN gatau g2 ON t.arrival_station_id = g2.id
    WHERE d.id = $booking_id AND d.user_id = {$_SESSION['user_id']}";

$booking_result = mysqli_query($conn, $booking_query);
$booking = mysqli_fetch_assoc($booking_result);

if (!$booking) {
    header('Location: dat-ve.php');
    exit();
}

// Xử lý xác nhận đặt vé
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $update_query = "UPDATE datve SET status = 'confirmed' WHERE id = $booking_id";
    if (mysqli_query($conn, $update_query)) {
        header('Location: camon.php?id=' . $booking_id);
        exit();
    }
}
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <!-- Thông tin đặt vé -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-2xl font-bold text-[#003366] mb-4">Xác nhận đặt vé</h2>
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-semibold text-[#003366]"><?php echo htmlspecialchars($booking['train_name']); ?></h3>
                    <p class="text-gray-600">Mã tàu: <?php echo htmlspecialchars($booking['train_number']); ?></p>
                </div>
                <div class="flex justify-between items-center">
                    <div class="text-center">
                        <p class="font-semibold"><?php echo htmlspecialchars($booking['departure_station']); ?></p>
                        <p class="text-gray-600"><?php echo htmlspecialchars($booking['departure_city']); ?></p>
                        <p class="text-[#003366]"><?php echo date('H:i', strtotime($booking['departure_time'])); ?></p>
                    </div>
                    <div class="hidden md:block">
                        <div class="w-32 h-0.5 bg-gray-300"></div>
                        <p class="text-center text-sm text-gray-500 mt-1">
                            <?php 
                            $departure = new DateTime($booking['departure_time']);
                            $arrival = new DateTime($booking['arrival_time']);
                            $interval = $departure->diff($arrival);
                            echo $interval->format('%Hh%ip');
                            ?>
                        </p>
                    </div>
                    <div class="text-center">
                        <p class="font-semibold"><?php echo htmlspecialchars($booking['arrival_station']); ?></p>
                        <p class="text-gray-600"><?php echo htmlspecialchars($booking['arrival_city']); ?></p>
                        <p class="text-[#003366]"><?php echo date('H:i', strtotime($booking['arrival_time'])); ?></p>
                    </div>
                </div>
                <div class="border-t pt-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-gray-600">Ngày đi:</p>
                            <p class="font-semibold"><?php echo date('d/m/Y', strtotime($booking['booking_date'])); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600">Số lượng vé:</p>
                            <p class="font-semibold"><?php echo $booking['number_of_tickets']; ?> vé</p>
                        </div>
                    </div>
                </div>
                <div class="border-t pt-4">
                    <div class="flex justify-between items-center">
                        <p class="text-lg font-semibold">Tổng tiền:</p>
                        <p class="text-2xl font-bold text-[#003366]"><?php echo number_format($booking['total_amount'], 0, ',', '.'); ?> đ</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form xác nhận -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <form action="" method="POST" class="space-y-6">
                <div class="text-center">
                    <p class="text-gray-600 mb-4">Vui lòng xác nhận thông tin đặt vé của bạn</p>
                    <button type="submit" class="bg-[#003366] text-white py-3 px-8 rounded-md hover:bg-[#002244] transition duration-300">
                        Xác nhận đặt vé
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>