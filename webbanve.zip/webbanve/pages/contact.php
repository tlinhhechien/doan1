<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $message = trim($_POST['message']);

    if (empty($name) || empty($email) || empty($phone)) {
        $_SESSION['error'] = "Vui lòng điền đầy đủ các trường bắt buộc!";
    } else {
        $stmt = $conn->prepare("INSERT INTO contacts (name, email, phone, message) VALUES (:name, :email, :phone, :message)");
        $stmt->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'message' => $message
        ]);

        $_SESSION['success'] = "Tin nhắn của bạn đã được gửi thành công!";
        header("Location: contact.php");
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>
<div class="container mx-auto px-4 py-16">
    <div class="max-w-6xl mx-auto">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">Liên Hệ Với Chúng Tôi</h2>
            <p class="text-gray-600">Chúng tôi luôn sẵn sàng lắng nghe ý kiến của bạn</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Form Liên Hệ -->
            <div class="bg-white rounded-lg shadow-lg p-8">
                <form method="POST" action="pages/contact.php" class="space-y-6">
                    <?php if (isset($_SESSION['error'])) { ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                            <span class="block sm:inline"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></span>
                        </div>
                    <?php } ?>

                    <?php if (isset($_SESSION['success'])) { ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                            <span class="block sm:inline"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></span>
                        </div>
                    <?php } ?>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Họ tên <span class="text-red-500">*</span></label>
                        <input type="text" name="name" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                               placeholder="Nhập họ tên của bạn">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email <span class="text-red-500">*</span></label>
                        <input type="email" name="email" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                               placeholder="Nhập email của bạn">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Số điện thoại <span class="text-red-500">*</span></label>
                        <input type="text" name="phone" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                               placeholder="Nhập số điện thoại của bạn">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Tin nhắn</label>
                        <textarea name="message" rows="5" 
                                  class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                  placeholder="Nhập nội dung tin nhắn của bạn"></textarea>
                    </div>

                    <div>
                        <button type="submit" 
                                class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Gửi tin nhắn
                        </button>
                    </div>
                </form>
            </div>

            <!-- Thông Tin Liên Hệ -->
            <div class="space-y-6">
                <div class="bg-white rounded-lg shadow-lg p-8">
                    <h3 class="text-xl font-semibold text-gray-800 mb-6">Thông Tin Liên Hệ</h3>
                    
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <i class="fas fa-map-marker-alt text-blue-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <h4 class="text-lg font-medium text-gray-800">Địa chỉ</h4>
                                <p class="mt-1 text-gray-600">123 Đường ABC, Quận XYZ, TP.HCM</p>
                            </div>
                        </div>

                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <i class="fas fa-phone text-blue-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <h4 class="text-lg font-medium text-gray-800">Điện thoại</h4>
                                <p class="mt-1 text-gray-600">+84 123 456 789</p>
                            </div>
                        </div>

                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <i class="fas fa-envelope text-blue-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <h4 class="text-lg font-medium text-gray-800">Email</h4>
                                <p class="mt-1 text-gray-600">contact@example.com</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-lg p-8">
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">Giờ Làm Việc</h3>
                    <div class="space-y-2">
                        <p class="text-gray-600">Thứ 2 - Thứ 6: 8:00 - 17:30</p>
                        <p class="text-gray-600">Thứ 7: 8:00 - 12:00</p>
                        <p class="text-gray-600">Chủ nhật: Nghỉ</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>