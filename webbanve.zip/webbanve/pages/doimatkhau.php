<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Kiểm tra mật khẩu hiện tại
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = :id");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 6) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :id");
                $update_stmt->execute([
                    'password' => $hashed_password,
                    'id' => $_SESSION['user_id']
                ]);
                $success_message = "Mật khẩu đã được cập nhật thành công!";
            } else {
                $error_message = "Mật khẩu mới phải có ít nhất 6 ký tự!";
            }
        } else {
            $error_message = "Mật khẩu mới và xác nhận mật khẩu không khớp!";
        }
    } else {
        $error_message = "Mật khẩu hiện tại không đúng!";
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container mx-auto px-4 py-16">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Header Section -->
            <div class="bg-[#003366] px-6 py-8 text-center">
                <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-white flex items-center justify-center">
                    <i class="fas fa-key text-4xl text-[#003366]"></i>
                </div>
                <h1 class="text-2xl font-bold text-white">Đổi Mật Khẩu</h1>
            </div>

            <!-- Form Section -->
            <div class="p-6">
                <?php if ($success_message): ?>
                    <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                        <span class="block sm:inline"><?php echo $success_message; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                        <span class="block sm:inline"><?php echo $error_message; ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="doimatkhau.php" class="space-y-6">
                    <div>
                        <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">
                            Mật khẩu hiện tại
                        </label>
                        <div class="relative">
                            <input type="password" 
                                   id="current_password" 
                                   name="current_password" 
                                   required
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-[#003366]"
                                   placeholder="Nhập mật khẩu hiện tại">
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">
                            Mật khẩu mới
                        </label>
                        <div class="relative">
                            <input type="password" 
                                   id="new_password" 
                                   name="new_password" 
                                   required
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-[#003366]"
                                   placeholder="Nhập mật khẩu mới">
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                                <i class="fas fa-key text-gray-400"></i>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">
                            Xác nhận mật khẩu mới
                        </label>
                        <div class="relative">
                            <input type="password" 
                                   id="confirm_password" 
                                   name="confirm_password" 
                                   required
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-[#003366]"
                                   placeholder="Nhập lại mật khẩu mới">
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                                <i class="fas fa-check-circle text-gray-400"></i>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center space-x-4">
                        <button type="submit" 
                                class="flex-1 bg-[#003366] text-white px-6 py-3 rounded-lg text-center font-medium hover:bg-[#002244] transition-colors duration-200">
                            <i class="fas fa-save mr-2"></i>
                            Cập nhật mật khẩu
                        </button>
                        <a href="account.php" 
                           class="flex-1 bg-gray-500 text-white px-6 py-3 rounded-lg text-center font-medium hover:bg-gray-600 transition-colors duration-200">
                            <i class="fas fa-arrow-left mr-2"></i>
                            Quay lại
                        </a>
                    </div>
                </form>

                <!-- Password Requirements -->
                <div class="mt-8 p-4 bg-gray-50 rounded-lg">
                    <h3 class="text-sm font-medium text-gray-700 mb-2">Yêu cầu mật khẩu:</h3>
                    <ul class="text-sm text-gray-600 space-y-1">
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-500 mr-2"></i>
                            Ít nhất 6 ký tự
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-500 mr-2"></i>
                            Nên bao gồm chữ hoa và chữ thường
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-500 mr-2"></i>
                            Nên bao gồm số và ký tự đặc biệt
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>