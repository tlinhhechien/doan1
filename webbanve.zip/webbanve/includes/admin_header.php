<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Đường sắt Việt Nam</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md fixed w-full top-0 z-50">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <a href="/webbanve/admin/index.php" class="flex items-center">

                    <span class="ml-2 text-xl font-bold text-gray-800">Đường sắt Việt Nam</span>
                </a>

                <!-- User Info -->
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user['username'] ?? 'Admin'); ?></p>
                        <p class="text-xs text-gray-500"><?php echo isset($user['role']) ? ucfirst($user['role']) : 'Administrator'; ?></p>
                    </div>
                    <a href="/webbanve/processes/logout.php" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="flex h-screen pt-16">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-md fixed h-full">
            <nav class="mt-5 px-2">
            <a href="/webbanve/admin/index.php" class="group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-900 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-tachometer-alt mr-3 h-6 w-6 text-gray-500 group-hover:text-gray-500"></i>
    Dashboard
</a>
<a href="/webbanve/admin/users-admin.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-users-cog mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý người dùng
</a>
<a href="/webbanve/admin/contacts-admin.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-address-book mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý liên hệ
</a>
<a href="/webbanve/admin/bookings.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-file-alt mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý Đơn Đặt
</a>
<a href="/webbanve/admin/tickets.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-ticket-alt mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý Đặt Vé
</a>
<a href="/webbanve/admin/train_types.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-train mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý Loại Tàu
</a>
<a href="/webbanve/admin/stations.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-map-marker-alt mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Quản lý Ga
</a>
<a href="/webbanve/admin/maintenance.php" class="mt-1 group flex items-center px-2 py-2 text-base leading-6 font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus:bg-gray-50 transition ease-in-out duration-150">
    <i class="fas fa-tools mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500"></i>
    Lịch bảo dưỡng
</a>

            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="flex-1 ml-64 p-8"> 