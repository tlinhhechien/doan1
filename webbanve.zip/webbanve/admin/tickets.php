<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Xử lý xóa vé tàu (sẽ hoàn thiện sau khi có form xóa)
if (isset($_POST['delete_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    // Logic xóa sẽ được thêm vào đây
    // Bao gồm xóa ảnh liên quan
    // Ví dụ: DELETE FROM tuyenduong WHERE id = :ticket_id
}

// Lấy danh sách vé tàu từ database
$tickets_query = "SELECT t.*,
                  l.train_name, l.train_number,
                  g1.station_name AS departure_station,
                  g2.station_name AS arrival_station
                  FROM tuyenduong t
                  JOIN loaitau l ON t.train_id = l.id
                  JOIN gatau g1 ON t.departure_station_id = g1.id
                  JOIN gatau g2 ON t.arrival_station_id = g2.id
                  ORDER BY t.id DESC";

$tickets_stmt = $conn->query($tickets_query);
$tickets = $tickets_stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Quản lý vé tàu</h1>

<!-- Nút thêm mới -->
<div class="mb-4">
    <a href="add_ticket.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm vé tàu mới</a>
</div>

<!-- Bảng danh sách vé tàu -->
<div class="bg-white shadow-md rounded-lg overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chuyến tàu</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ga đi</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ga đến</th>
                     <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thời gian đi</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thời gian đến</th>
                     <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Giá</th>
                      <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($tickets as $ticket): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#<?php echo htmlspecialchars($ticket['id'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars(($ticket['train_name'] ?? '') . ' (' . ($ticket['train_number'] ?? '') . ')'); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($ticket['departure_station'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($ticket['arrival_station'] ?? ''); ?></td>
                     <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($ticket['departure_time'] ?? ''); ?></td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($ticket['arrival_time'] ?? ''); ?></td>
                       <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo number_format($ticket['price'] ?? 0, 0, ',', '.'); ?> đ</td>
                         <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($ticket['status'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="edit_ticket.php?id=<?php echo htmlspecialchars($ticket['id'] ?? ''); ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Sửa</a>
                        <form method="POST" action="" class="inline-block" onsubmit="return confirm('Bạn có chắc chắn muốn xóa vé tàu này không?');">
                            <input type="hidden" name="delete_ticket" value="1">
                            <input type="hidden" name="ticket_id" value="<?php echo htmlspecialchars($ticket['id'] ?? ''); ?>">
                             <input type="hidden" name="ticket_image" value="<?php echo htmlspecialchars($ticket['image_path'] ?? ''); ?>"> <!-- Lấy đường dẫn ảnh để xóa -->
                            <button type="submit" class="text-red-600 hover:text-red-900">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

