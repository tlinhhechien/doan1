<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Lấy ID loại tàu từ URL
$type_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin loại tàu hiện tại từ database
$train_type = null;
if ($type_id > 0) {
    $type_query = "SELECT * FROM loaitau WHERE id = :type_id";
    $type_stmt = $conn->prepare($type_query);
    $type_stmt->execute([':type_id' => $type_id]);
    $train_type = $type_stmt->fetch(PDO::FETCH_ASSOC);

    // Nếu không tìm thấy loại tàu, chuyển hướng
    if (!$train_type) {
        $_SESSION['error'] = "Loại tàu không tồn tại.";
        header('Location: train_types.php');
        exit();
    }
} else {
    // Nếu không có ID trên URL, chuyển hướng
    $_SESSION['error'] = "Không có ID loại tàu được cung cấp.";
    header('Location: train_types.php');
    exit();
}

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_name = $_POST['train_name'];
    $train_number = $_POST['train_number'];
    $description = $_POST['description'];

    try {
        $update_query = "UPDATE loaitau SET 
                          train_name = :train_name, 
                          train_number = :train_number, 
                          description = :description 
                         WHERE id = :type_id";
        $stmt = $conn->prepare($update_query);
        $stmt->execute([
            ':train_name' => $train_name,
            ':train_number' => $train_number,
            ':description' => $description,
            ':type_id' => $type_id
        ]);

        $_SESSION['success'] = "Cập nhật loại tàu thành công!";
        header('Location: train_types.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi cập nhật loại tàu: " . $e->getMessage();
    }
    // Nếu có lỗi, hiển thị form lại với thông báo lỗi
}

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Chỉnh sửa loại tàu: <?php echo htmlspecialchars($train_type['train_name'] ?? ''); ?></h1>

<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<div class="bg-white shadow-md rounded-lg p-6">
    <form action="edit_train_type.php?id=<?php echo htmlspecialchars($type_id); ?>" method="POST" class="space-y-4">
        <div>
            <label for="train_name" class="block text-sm font-medium text-gray-700">Tên loại tàu:</label>
            <input type="text" name="train_name" id="train_name" value="<?php echo htmlspecialchars($train_type['train_name'] ?? ''); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="train_number" class="block text-sm font-medium text-gray-700">Mã tàu:</label>
            <input type="text" name="train_number" id="train_number" value="<?php echo htmlspecialchars($train_type['train_number'] ?? ''); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="description" class="block text-sm font-medium text-gray-700">Mô tả (Tùy chọn):</label>
            <textarea name="description" id="description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"><?php echo htmlspecialchars($train_type['description'] ?? ''); ?></textarea>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cập nhật loại tàu</button>
        </div>
    </form>
</div>

<?php include '../includes/admin_footer.php'; ?> 