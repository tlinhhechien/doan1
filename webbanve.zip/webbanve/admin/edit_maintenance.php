<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Lấy ID từ URL
$id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$id) {
    $_SESSION['error'] = "Không tìm thấy lịch bảo dưỡng!";
    header('Location: maintenance.php');
    exit();
}

// Lấy danh sách tàu
$trains_query = "SELECT id, train_name, train_number FROM loaitau ORDER BY train_name";
$trains_stmt = $conn->query($trains_query);
$trains = $trains_stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy thông tin lịch bảo dưỡng
try {
    $query = "SELECT * FROM baoduong WHERE id = :id";
    $stmt = $conn->prepare($query);
    $stmt->execute([':id' => $id]);
    $maintenance = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$maintenance) {
        $_SESSION['error'] = "Không tìm thấy lịch bảo dưỡng!";
        header('Location: maintenance.php');
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = "Lỗi khi lấy thông tin lịch bảo dưỡng: " . $e->getMessage();
    header('Location: maintenance.php');
    exit();
}

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $schedule_time = $_POST['schedule_time'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    try {
        $update_query = "UPDATE baoduong 
                        SET train_id = :train_id, 
                            schedule_time = :schedule_time, 
                            description = :description, 
                            status = :status 
                        WHERE id = :id";
        $stmt = $conn->prepare($update_query);
        $stmt->execute([
            ':train_id' => $train_id,
            ':schedule_time' => $schedule_time,
            ':description' => $description,
            ':status' => $status,
            ':id' => $id
        ]);

        $_SESSION['success'] = "Cập nhật lịch bảo dưỡng thành công!";
        header('Location: maintenance.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi cập nhật lịch bảo dưỡng: " . $e->getMessage();
    }
    header('Location: edit_maintenance.php?id=' . $id);
    exit();
}

include '../includes/admin_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Chỉnh sửa lịch bảo dưỡng</h1>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
            <?php unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <div class="bg-white shadow-md rounded-lg p-6">
        <form action="edit_maintenance.php?id=<?php echo $id; ?>" method="POST" class="space-y-4">
            <div>
                <label for="train_id" class="block text-sm font-medium text-gray-700">Chọn tàu:</label>
                <select name="train_id" id="train_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn tàu --</option>
                    <?php foreach ($trains as $train): ?>
                        <option value="<?php echo $train['id']; ?>" <?php echo $train['id'] == $maintenance['train_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($train['train_name'] . ' (' . $train['train_number'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="schedule_time" class="block text-sm font-medium text-gray-700">Thời gian bảo dưỡng:</label>
                <input type="datetime-local" name="schedule_time" id="schedule_time" required 
                       value="<?php echo date('Y-m-d\TH:i', strtotime($maintenance['schedule_time'])); ?>"
                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Mô tả:</label>
                <textarea name="description" id="description" rows="3" 
                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"><?php echo htmlspecialchars($maintenance['description'] ?? ''); ?></textarea>
            </div>

            <div>
                <label for="status" class="block text-sm font-medium text-gray-700">Trạng thái:</label>
                <select name="status" id="status" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="scheduled" <?php echo $maintenance['status'] == 'scheduled' ? 'selected' : ''; ?>>Đã lên lịch</option>
                    <option value="in_progress" <?php echo $maintenance['status'] == 'in_progress' ? 'selected' : ''; ?>>Đang bảo dưỡng</option>
                    <option value="completed" <?php echo $maintenance['status'] == 'completed' ? 'selected' : ''; ?>>Hoàn thành</option>
                    <option value="cancelled" <?php echo $maintenance['status'] == 'cancelled' ? 'selected' : ''; ?>>Đã hủy</option>
                </select>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Cập nhật lịch bảo dưỡng
                </button>
            </div>
        </form>
    </div>
</div>