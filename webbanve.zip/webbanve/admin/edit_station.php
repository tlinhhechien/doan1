<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Lấy ID ga tàu từ URL
$station_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin ga tàu hiện tại từ database
$station = null;
if ($station_id > 0) {
    $station_query = "SELECT * FROM gatau WHERE id = :station_id";
    $station_stmt = $conn->prepare($station_query);
    $station_stmt->execute([':station_id' => $station_id]);
    $station = $station_stmt->fetch(PDO::FETCH_ASSOC);

    // Nếu không tìm thấy ga tàu, chuyển hướng
    if (!$station) {
        $_SESSION['error'] = "Ga tàu không tồn tại.";
        header('Location: stations.php');
        exit();
    }
} else {
    // Nếu không có ID trên URL, chuyển hướng
    $_SESSION['error'] = "Không có ID ga tàu được cung cấp.";
    header('Location: stations.php');
    exit();
}

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $station_name = $_POST['station_name'];
    $city = $_POST['city'];
    $address = $_POST['address'];

    try {
        $update_query = "UPDATE gatau SET 
                          station_name = :station_name, 
                          city = :city, 
                          address = :address 
                         WHERE id = :station_id";
        $stmt = $conn->prepare($update_query);
        $stmt->execute([
            ':station_name' => $station_name,
            ':city' => $city,
            ':address' => $address,
            ':station_id' => $station_id
        ]);

        $_SESSION['success'] = "Cập nhật ga tàu thành công!";
        header('Location: stations.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi cập nhật ga tàu: " . $e->getMessage();
    }
    // Nếu có lỗi, hiển thị form lại với thông báo lỗi
}

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Chỉnh sửa ga tàu: <?php echo htmlspecialchars($station['station_name'] ?? ''); ?></h1>

<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<div class="bg-white shadow-md rounded-lg p-6">
    <form action="edit_station.php?id=<?php echo htmlspecialchars($station_id); ?>" method="POST" class="space-y-4">
        <div>
            <label for="station_name" class="block text-sm font-medium text-gray-700">Tên ga:</label>
            <input type="text" name="station_name" id="station_name" value="<?php echo htmlspecialchars($station['station_name'] ?? ''); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="city" class="block text-sm font-medium text-gray-700">Thành phố:</label>
            <input type="text" name="city" id="city" value="<?php echo htmlspecialchars($station['city'] ?? ''); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="address" class="block text-sm font-medium text-gray-700">Địa chỉ:</label>
            <textarea name="address" id="address" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"><?php echo htmlspecialchars($station['address'] ?? ''); ?></textarea>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cập nhật ga tàu</button>
        </div>
    </form>
</div>

