<?php
require_once '../includes/config.php';
require_once '../includes/admin_header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Xử lý cập nhật trạng thái
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $booking_id = intval($_POST['booking_id']);
    $status = $_POST['status'];
    $admin_note = $_POST['admin_note'];
    
    $update_query = "UPDATE datve SET status = ?, admin_note = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "ssi", $status, $admin_note, $booking_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Cập nhật trạng thái đơn hàng thành công!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra khi cập nhật trạng thái!";
    }
    
    header('Location: bookings.php');
    exit();
}

// Lấy danh sách đơn hàng
$bookings_query = "SELECT d.*, 
    u.username, u.email,
    t.departure_time, t.arrival_time,
    l.train_name, l.train_number,
    g1.station_name as departure_station, g1.city as departure_city,
    g2.station_name as arrival_station, g2.city as arrival_city
    FROM datve d
    JOIN users u ON d.user_id = u.id
    JOIN tuyenduong t ON d.route_id = t.id
    JOIN loaitau l ON t.train_id = l.id
    JOIN gatau g1 ON t.departure_station_id = g1.id
    JOIN gatau g2 ON t.arrival_station_id = g2.id
    ORDER BY d.created_at DESC";

$bookings_stmt = $conn->query($bookings_query);
$bookings = $bookings_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mx-auto px-4 py-8">
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-[#003366]">Quản lý đơn hàng</h2>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mã đơn</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Khách hàng</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chuyến tàu</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ngày đi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Số vé</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tổng tiền</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                #<?php echo $booking['id']; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo htmlspecialchars($booking['username']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($booking['email']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo htmlspecialchars($booking['train_name']); ?></div>
                                <div class="text-sm text-gray-500">
                                    <?php echo htmlspecialchars($booking['departure_station']); ?> - 
                                    <?php echo htmlspecialchars($booking['arrival_station']); ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo date('d/m/Y', strtotime($booking['booking_date'])); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo $booking['number_of_tickets']; ?> vé
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo number_format($booking['total_amount'], 0, ',', '.'); ?> đ
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php
                                    switch ($booking['status']) {
                                        case 'pending':
                                            echo 'bg-yellow-100 text-yellow-800';
                                            break;
                                        case 'confirmed':
                                            echo 'bg-green-100 text-green-800';
                                            break;
                                        case 'cancelled':
                                            echo 'bg-red-100 text-red-800';
                                            break;
                                    }
                                    ?>">
                                    <?php
                                    switch ($booking['status']) {
                                        case 'pending':
                                            echo 'Chờ xác nhận';
                                            break;
                                        case 'confirmed':
                                            echo 'Đã xác nhận';
                                            break;
                                        case 'cancelled':
                                            echo 'Đã hủy';
                                            break;
                                    }
                                    ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button onclick="openModal(<?php echo $booking['id']; ?>, '<?php echo $booking['status']; ?>', '<?php echo htmlspecialchars($booking['admin_note']); ?>')"
                                    class="text-[#003366] hover:text-[#002244]">
                                    Cập nhật
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal cập nhật trạng thái -->
<div id="updateModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-[#003366] mb-4">Cập nhật trạng thái đơn hàng</h3>
            <form action="" method="POST" class="space-y-4">
                <input type="hidden" name="booking_id" id="booking_id">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Trạng thái</label>
                    <select name="status" id="status" class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50">
                        <option value="pending">Chờ xác nhận</option>
                        <option value="confirmed">Đã xác nhận</option>
                        <option value="cancelled">Đã hủy</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Ghi chú</label>
                    <textarea name="admin_note" id="admin_note" rows="3" class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50"></textarea>
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Hủy
                    </button>
                    <button type="submit" class="px-4 py-2 bg-[#003366] text-white rounded-md hover:bg-[#002244]">
                        Cập nhật
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(bookingId, status, adminNote) {
    document.getElementById('booking_id').value = bookingId;
    document.getElementById('status').value = status;
    document.getElementById('admin_note').value = adminNote;
    document.getElementById('updateModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('updateModal').classList.add('hidden');
}
</script>

