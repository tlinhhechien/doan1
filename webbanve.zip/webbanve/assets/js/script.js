// Dữ liệu mẫu cho các ga tàu
const stations = [
    { id: 1, name: 'Hà Nội' },
    { id: 2, name: 'Hải Phòng' },
    { id: 3, name: 'Đà Nẵng' },
    { id: 4, name: 'Huế' },
    { id: 5, name: 'Sài Gòn' },
    { id: 6, name: 'Nha Trang' },
    { id: 7, name: 'Vinh' },
    { id: 8, name: 'Lào Cai' }
];

// Dữ liệu mẫu cho các chuyến tàu
const trains = [
    {
        id: 'HP1',
        name: 'Tàu Hoa Phượng Đỏ HP1',
        from: 'Hà Nội',
        to: 'Hải Phòng',
        duration: '2h25p',
        price: 250000
    },
    {
        id: 'SE1',
        name: 'Tàu nhanh chất lượng SE1',
        from: 'Hà Nội',
        to: 'Huế',
        duration: '13h40p',
        price: 571000
    }
];

// Khởi tạo các select box
document.addEventListener('DOMContentLoaded', function() {
    // Khởi tạo select box ga đi
    const fromStationSelect = document.getElementById('ga-di');
    stations.forEach(station => {
        const option = document.createElement('option');
        option.value = station.id;
        option.textContent = station.name;
        fromStationSelect.appendChild(option);
    });

    // Khởi tạo select box ga đến
    const toStationSelect = document.getElementById('ga-den');
    stations.forEach(station => {
        const option = document.createElement('option');
        option.value = station.id;
        option.textContent = station.name;
        toStationSelect.appendChild(option);
    });

    // Khởi tạo select box số lượng vé
    const ticketQuantitySelect = document.getElementById('so-luong-ve');
    for (let i = 1; i <= 10; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = `${i} vé`;
        ticketQuantitySelect.appendChild(option);
    }

    // Khởi tạo date picker
    const dateInput = document.getElementById('ngay-di');
    const today = new Date();
    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 3); // Cho phép đặt vé trước 3 tháng

    dateInput.min = today.toISOString().split('T')[0];
    dateInput.max = maxDate.toISOString().split('T')[0];
});

// Xử lý form tìm chuyến tàu
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const fromStation = document.getElementById('ga-di').value;
    const toStation = document.getElementById('ga-den').value;
    const quantity = document.getElementById('so-luong-ve').value;
    const date = document.getElementById('ngay-di').value;

    // Kiểm tra điều kiện
    if (fromStation === toStation) {
        alert('Ga đi và ga đến không được trùng nhau!');
        return;
    }

    // Tìm các chuyến tàu phù hợp
    const availableTrains = trains.filter(train => 
        train.from === stations.find(s => s.id === parseInt(fromStation)).name &&
        train.to === stations.find(s => s.id === parseInt(toStation)).name
    );

    if (availableTrains.length === 0) {
        alert('Không tìm thấy chuyến tàu phù hợp!');
        return;
    }

    // Hiển thị kết quả tìm kiếm
    displaySearchResults(availableTrains, quantity, date);
});

// Hiển thị kết quả tìm kiếm
function displaySearchResults(trains, quantity, date) {
    const resultsContainer = document.createElement('div');
    resultsContainer.className = 'max-w-[1200px] mx-auto mt-4 p-4 bg-white rounded-md shadow-sm';
    
    let html = `
        <h3 class="text-lg font-semibold mb-4">Kết quả tìm kiếm</h3>
        <div class="grid gap-4">
    `;

    trains.forEach(train => {
        const totalPrice = train.price * quantity;
        html += `
            <div class="border rounded-md p-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h4 class="font-semibold">${train.name}</h4>
                        <div class="text-sm text-gray-600">
                            ${train.from} → ${train.to} (${train.duration})
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-orange-500 font-semibold">${totalPrice.toLocaleString('vi-VN')} đ</div>
                        <button onclick="bookTicket('${train.id}', ${quantity}, '${date}')" 
                                class="mt-2 bg-[#ff8c00] text-white px-4 py-2 rounded hover:bg-[#e07b00]">
                            Đặt vé
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    html += '</div>';
    resultsContainer.innerHTML = html;

    // Xóa kết quả cũ nếu có
    const oldResults = document.querySelector('.max-w-\\[1200px\\].mx-auto.mt-4');
    if (oldResults) {
        oldResults.remove();
    }

    // Thêm kết quả mới vào trang
    document.querySelector('section').after(resultsContainer);
}

// Xử lý đặt vé
function bookTicket(trainId, quantity, date) {
    // Kiểm tra đăng nhập
    if (!isLoggedIn()) {
        alert('Vui lòng đăng nhập để đặt vé!');
        return;
    }

    // Xử lý đặt vé
    alert(`Đặt vé thành công!\nChuyến tàu: ${trainId}\nSố lượng: ${quantity}\nNgày đi: ${date}`);
}

// Kiểm tra đăng nhập
function isLoggedIn() {
    // Giả lập kiểm tra đăng nhập
    return false;
}

// Xử lý hiển thị/ẩn menu mobile
document.querySelector('.md\\:hidden').addEventListener('click', function() {
    const nav = document.querySelector('nav');
    nav.classList.toggle('hidden');
});

// Xử lý hiển thị thêm đánh giá
document.querySelector('button:contains("Hiển thị 37 đánh giá")').addEventListener('click', function() {
    // Thêm logic hiển thị thêm đánh giá ở đây
    alert('Đang tải thêm đánh giá...');
}); 