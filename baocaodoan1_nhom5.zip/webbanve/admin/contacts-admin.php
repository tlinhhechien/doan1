<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Xử lý xóa liên hệ
if (isset($_POST['delete_contact'])) {
    $contact_id = $_POST['contact_id'];
    try {
        $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
        $stmt->execute([$contact_id]);
        $_SESSION['success'] = "Xóa liên hệ thành công!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi xóa liên hệ!";
    }
    header('Location: contacts-admin.php');
    exit();
}

// Xử lý cập nhật trạng thái
if (isset($_POST['update_status'])) {
    $contact_id = $_POST['contact_id'];
    $new_status = $_POST['status'];
    try {
        $stmt = $conn->prepare("UPDATE contacts SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $contact_id]);
        $_SESSION['success'] = "Cập nhật trạng thái thành công!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi cập nhật trạng thái!";
    }
    header('Location: contacts-admin.php');
    exit();
}

// Lấy danh sách liên hệ
$stmt = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");
$contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<!-- Contacts Management Content -->
<div class="space-y-6">
    <!-- Header -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl font-bold text-gray-800">Quản lý liên hệ</h1>
        </div>
    </div>

    <!-- Messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
            <?php unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
            <?php unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <!-- Contacts Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="relative overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 table-auto">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Họ tên</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Số điện thoại</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nội dung</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ngày gửi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#<?php echo $contact['id']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['name']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['email']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['phone']); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-900">
                            <div class="max-w-xs truncate">
                                <?php echo htmlspecialchars($contact['message']); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <form method="POST" class="flex items-center space-x-2">
                                <input type="hidden" name="contact_id" value="<?php echo $contact['id']; ?>">
                                <select name="status" class="text-sm border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                                    <option value="pending" <?php echo $contact['status'] === 'pending' ? 'selected' : ''; ?>>Chờ xử lý</option>
                                    <option value="processing" <?php echo $contact['status'] === 'processing' ? 'selected' : ''; ?>>Đang xử lý</option>
                                    <option value="completed" <?php echo $contact['status'] === 'completed' ? 'selected' : ''; ?>>Đã xử lý</option>
                                </select>
                                <button type="submit" name="update_status" class="text-primary hover:text-primary/80">
                                    <i class="fas fa-save"></i>
                                </button>
                            </form>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?php echo date('d/m/Y H:i', strtotime($contact['created_at'])); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex items-center space-x-3">
                                <form method="POST" class="inline" onsubmit="return confirm('Bạn có chắc chắn muốn xóa liên hệ này?');">
                                    <input type="hidden" name="contact_id" value="<?php echo $contact['id']; ?>">
                                    <button type="submit" name="delete_contact" class="text-red-600 hover:text-red-800">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</main>
</div>
</body>
</html>