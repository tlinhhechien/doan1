<?php
session_start();
include dirname(__DIR__) . '/includes/config.php';

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /webbanve/pages/login.php');
    exit;
}

// Tổng doanh thu
$stmt = $conn->query("SELECT SUM(total_amount) AS total_revenue FROM datve WHERE status = 'confirmed'");
$total_revenue = $stmt->fetch(PDO::FETCH_ASSOC)['total_revenue'] ?? 0;

// Vé bán chạy (Top 5 tuyến đường)
$stmt = $conn->query("
    SELECT td.id, td.departure_time, td.arrival_time, td.price,
           g1.station_name AS ga_di, g2.station_name AS ga_den,
           SUM(dv.number_of_tickets) AS total_tickets
    FROM datve dv
    JOIN tuyenduong td ON dv.route_id = td.id
    JOIN gatau g1 ON td.departure_station_id = g1.id
    JOIN gatau g2 ON td.arrival_station_id = g2.id
    WHERE dv.status = 'confirmed'
    GROUP BY dv.route_id
    ORDER BY total_tickets DESC
    LIMIT 5
");
$top_routes = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<div class="space-y-6">
    <h1 class="text-xl font-bold">Thống kê doanh số</h1>

    <div class="bg-white p-4 rounded shadow">
        <h2 class="text-lg font-semibold">Tổng doanh thu:</h2>
        <p class="text-green-600 font-bold text-2xl"><?= number_format($total_revenue, 0, ',', '.') ?> VND</p>
    </div>

    <div class="bg-white p-6 rounded-lg shadow-lg mt-6">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">🔥 Tuyến đường bán chạy nhất</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm text-left">
            <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="px-4 py-2">🚉 Tuyến</th>
                    <th class="px-4 py-2">🕒 Giờ đi - Giờ đến</th>
                    <th class="px-4 py-2">💵 Giá</th>
                    <th class="px-4 py-2">🎟️ Số vé đã bán</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php
                    $stmt = $conn->query("
                        SELECT td.id, td.departure_time, td.arrival_time, td.price,
                               g1.station_name AS ga_di, g2.station_name AS ga_den,
                               SUM(dv.number_of_tickets) AS total_tickets
                        FROM datve dv
                        JOIN tuyenduong td ON dv.route_id = td.id
                        JOIN gatau g1 ON td.departure_station_id = g1.id
                        JOIN gatau g2 ON td.arrival_station_id = g2.id
                        WHERE dv.status = 'confirmed'
                        GROUP BY dv.route_id
                        ORDER BY total_tickets DESC
                        LIMIT 3
                    ");
                    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $route):
                ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-4 py-2 font-medium text-gray-800"><?= $route['ga_di'] ?> → <?= $route['ga_den'] ?></td>
                    <td class="px-4 py-2 text-gray-600"><?= $route['departure_time'] ?> - <?= $route['arrival_time'] ?></td>
                    <td class="px-4 py-2 text-green-600 font-semibold"><?= number_format($route['price'], 0, ',', '.') ?> VND</td>
                    <td class="px-4 py-2 text-blue-600 font-bold"><?= $route['total_tickets'] ?></td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

</div>


