<!-- Phần home PC -->


<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include dirname(__DIR__) . '/includes/config.php';

// Kiểm tra đăng nhập và quyền truy cập
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}


// Lấy thông tin user
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Lấy thống kê
$stats = [
    'users' => 0,
    'contacts' => 0
];

// Đếm số lượng người dùng
$stmt = $conn->query("SELECT COUNT(*) as count FROM users");
$stats['users'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Đếm số lượng liên hệ
$stmt = $conn->query("SELECT COUNT(*) as count FROM contacts");
$stats['contacts'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Lấy liên hệ gần đây
$stmt = $conn->query("
    SELECT * FROM contacts 
    ORDER BY created_at DESC 
    LIMIT 5
");
$recent_contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<!-- Dashboard Content -->
<div class="space-y-6">
    <!-- Welcome Section -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h1 class="text-2xl font-bold text-gray-800">Xin chào, <?php echo htmlspecialchars($user['username']); ?>!</h1>
        <p class="text-gray-600 mt-2">Đây là tổng quan về hệ thống quản lý của bạn.</p>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Users Stats -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-users text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500">Người dùng</p>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo number_format($stats['users']); ?></p>
                </div>
            </div>
        </div>

        <!-- Contacts Stats -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-envelope text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500">Liên hệ</p>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo number_format($stats['contacts']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Contacts -->
    <div class="bg-white rounded-lg shadow-md">
        <div class="p-6 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800">Liên hệ gần đây</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Họ tên</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Số điện thoại</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ngày gửi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($recent_contacts)): ?>
                        <?php foreach ($recent_contacts as $contact): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#<?php echo $contact['id']; ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['name']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['email']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($contact['phone']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo date('d/m/Y H:i', strtotime($contact['created_at'])); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-sm text-gray-500">Không có liên hệ nào</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>


    <div class="bg-white p-6 rounded-lg shadow-lg mt-6">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">🔥 Tuyến đường bán chạy nhất</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm text-left">
            <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="px-4 py-2">🚉 Tuyến</th>
                    <th class="px-4 py-2">🕒 Giờ đi - Giờ đến</th>
                    <th class="px-4 py-2">💵 Giá</th>
                    <th class="px-4 py-2">🎟️ Số vé đã bán</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php
                    $stmt = $conn->query("
                        SELECT td.id, td.departure_time, td.arrival_time, td.price,
                               g1.station_name AS ga_di, g2.station_name AS ga_den,
                               SUM(dv.number_of_tickets) AS total_tickets
                        FROM datve dv
                        JOIN tuyenduong td ON dv.route_id = td.id
                        JOIN gatau g1 ON td.departure_station_id = g1.id
                        JOIN gatau g2 ON td.arrival_station_id = g2.id
                        WHERE dv.status = 'confirmed'
                        GROUP BY dv.route_id
                        ORDER BY total_tickets DESC
                        LIMIT 3
                    ");
                    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $route):
                ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-4 py-2 font-medium text-gray-800"><?= $route['ga_di'] ?> → <?= $route['ga_den'] ?></td>
                    <td class="px-4 py-2 text-gray-600"><?= $route['departure_time'] ?> - <?= $route['arrival_time'] ?></td>
                    <td class="px-4 py-2 text-green-600 font-semibold"><?= number_format($route['price'], 0, ',', '.') ?> VND</td>
                    <td class="px-4 py-2 text-blue-600 font-bold"><?= $route['total_tickets'] ?></td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

</div>

</main>
</div>
</body>
</html>

