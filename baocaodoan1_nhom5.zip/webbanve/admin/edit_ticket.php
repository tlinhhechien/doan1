<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}


// Lấy ID vé tàu từ URL
$ticket_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin vé tàu hiện tại từ database
$ticket = null;
if ($ticket_id > 0) {
    $ticket_query = "SELECT t.*,
                     l.train_name, l.train_number,
                     g1.station_name AS departure_station,
                     g2.station_name AS arrival_station
                     FROM tuyenduong t
                     JOIN loaitau l ON t.train_id = l.id
                     JOIN gatau g1 ON t.departure_station_id = g1.id
                     JOIN gatau g2 ON t.arrival_station_id = g2.id
                     WHERE t.id = :ticket_id";
    $ticket_stmt = $conn->prepare($ticket_query);
    $ticket_stmt->execute([':ticket_id' => $ticket_id]);
    $ticket = $ticket_stmt->fetch(PDO::FETCH_ASSOC);

    // Nếu không tìm thấy vé tàu, chuyển hướng
    if (!$ticket) {
        $_SESSION['error'] = "Vé tàu không tồn tại.";
        header('Location: tickets.php');
        exit();
    }
} else {
    // Nếu không có ID trên URL, chuyển hướng
    $_SESSION['error'] = "Không có ID vé tàu được cung cấp.";
    header('Location: tickets.php');
    exit();
}

// Lấy danh sách Ga tàu và Loại tàu cho dropdown
$stations_query = "SELECT id, station_name, city FROM gatau ORDER BY city, station_name";
$stations_stmt = $conn->query($stations_query);
$stations = $stations_stmt->fetchAll(PDO::FETCH_ASSOC);

$train_types_query = "SELECT id, train_name, train_number FROM loaitau ORDER BY train_name";
$train_types_stmt = $conn->query($train_types_query);
$train_types = $train_types_stmt->fetchAll(PDO::FETCH_ASSOC);

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $departure_station_id = $_POST['departure_station_id'];
    $arrival_station_id = $_POST['arrival_station_id'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $price = $_POST['price'];
    $status = $_POST['status'];
    $current_image_path = $ticket['image_path']; // Lấy đường dẫn ảnh hiện tại
    $new_image_path = $current_image_path; // Mặc định giữ nguyên ảnh cũ

    // Xử lý upload hình ảnh mới
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../images/'; // Thư mục lưu ảnh
        $image_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_file = $upload_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Kiểm tra loại file
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($imageFileType, $allowed_types)) {
             // Kiểm tra kích thước file (tùy chọn)
            if ($_FILES['image']['size'] < 5000000) { // 5MB
                 // Di chuyển file upload vào thư mục đích
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                    $new_image_path = 'images/' . $image_name; // Cập nhật đường dẫn ảnh mới
                    
                    // Xóa ảnh cũ nếu tồn tại và khác ảnh mặc định/ảnh mới
                    if ($current_image_path && file_exists('../' . $current_image_path) && $current_image_path != $new_image_path) {
                        unlink('../' . $current_image_path);
                    }

                } else {
                    $_SESSION['error'] = "Lỗi khi upload file ảnh mới.";
                }
            } else {
                 $_SESSION['error'] = "Kích thước file ảnh mới quá lớn.";
            }
        } else {
            $_SESSION['error'] = "Chỉ cho phép upload file JPG, JPEG, PNG, GIF cho ảnh mới.";
        }
    }
     
     // Chỉ cập nhật database nếu không có lỗi upload hoặc upload thành công
    if (!isset($_SESSION['error'])) {
        try {
            $update_query = "UPDATE tuyenduong SET 
                              train_id = :train_id, 
                              departure_station_id = :departure_station_id, 
                              arrival_station_id = :arrival_station_id, 
                              departure_time = :departure_time, 
                              arrival_time = :arrival_time, 
                              price = :price, 
                              status = :status, 
                              image_path = :image_path
                             WHERE id = :ticket_id";
            $stmt = $conn->prepare($update_query);
            $stmt->execute([
                ':train_id' => $train_id,
                ':departure_station_id' => $departure_station_id,
                ':arrival_station_id' => $arrival_station_id,
                ':departure_time' => $departure_time,
                ':arrival_time' => $arrival_time,
                ':price' => $price,
                ':status' => $status,
                ':image_path' => $new_image_path, // Sử dụng đường dẫn ảnh mới (hoặc cũ nếu không upload mới)
                ':ticket_id' => $ticket_id
            ]);

            $_SESSION['success'] = "Cập nhật vé tàu thành công!";
            header('Location: tickets.php');
            exit();

        } catch (PDOException $e) {
            $_SESSION['error'] = "Lỗi khi cập nhật vé tàu: " . $e->getMessage();
             // Có lỗi DB, xóa file ảnh mới vừa upload nếu có
            if ($new_image_path != $current_image_path && file_exists('../' . $new_image_path)) {
                unlink('../' . $new_image_path);
            }
        }
    } else {
         // Có lỗi upload ảnh, chuyển hướng
         // error message already set in upload section
    }
    // Nếu có lỗi (upload hoặc DB), hiển thị form lại với thông báo lỗi
    // Lấy lại dữ liệu vé tàu để hiển thị trong form sau khi có lỗi POST
    if ($ticket_id > 0) { // Chỉ lấy lại nếu ticket_id hợp lệ
         $ticket_query = "SELECT t.*,
                          l.train_name, l.train_number,
                          g1.station_name AS departure_station,
                          g2.station_name AS arrival_station
                          FROM tuyenduong t
                          JOIN loaitau l ON t.train_id = l.id
                          JOIN gatau g1 ON t.departure_station_id = g1.id
                          JOIN gatau g2 ON t.arrival_station_id = g2.id
                          WHERE t.id = :ticket_id";
         $ticket_stmt = $conn->prepare($ticket_query);
         $ticket_stmt->execute([':ticket_id' => $ticket_id]);
         $ticket = $ticket_stmt->fetch(PDO::FETCH_ASSOC);

         if (!$ticket) { // Double check if ticket still exists
             $_SESSION['error'] = "Vé tàu không tồn tại sau khi xử lý POST.";
             header('Location: tickets.php');
             exit();
         }
    }
    // Không redirect, hiển thị lại trang với thông báo lỗi
}

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Chỉnh sửa vé tàu: <?php echo htmlspecialchars($ticket['train_name'] . ' (' . $ticket['train_number'] . ')'); ?></h1>

<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<div class="bg-white shadow-md rounded-lg p-6">
    <form action="edit_ticket.php?id=<?php echo $ticket_id; ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
        <div>
            <label for="train_id" class="block text-sm font-medium text-gray-700">Loại tàu:</label>
            <select name="train_id" id="train_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="">-- Chọn loại tàu --</option>
                <?php foreach ($train_types as $type): ?>
                    <option value="<?php echo $type['id']; ?>" <?php echo $ticket['train_id'] == $type['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($type['train_name'] . ' (' . $type['train_number'] . ')'); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label for="departure_station_id" class="block text-sm font-medium text-gray-700">Ga đi:</label>
                <select name="departure_station_id" id="departure_station_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn ga đi --</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>" <?php echo $ticket['departure_station_id'] == $station['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="arrival_station_id" class="block text-sm font-medium text-gray-700">Ga đến:</label>
                <select name="arrival_station_id" id="arrival_station_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn ga đến --</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>" <?php echo $ticket['arrival_station_id'] == $station['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

         <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label for="departure_time" class="block text-sm font-medium text-gray-700">Thời gian đi:</label>
                <input type="time" name="departure_time" id="departure_time" value="<?php echo htmlspecialchars($ticket['departure_time']); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>
            <div>
                <label for="arrival_time" class="block text-sm font-medium text-gray-700">Thời gian đến:</label>
                <input type="time" name="arrival_time" id="arrival_time" value="<?php echo htmlspecialchars($ticket['arrival_time']); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>
        </div>

        <div>
            <label for="price" class="block text-sm font-medium text-gray-700">Giá:</label>
            <input type="number" name="price" id="price" value="<?php echo htmlspecialchars($ticket['price']); ?>" required min="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

         <div>
            <label for="status" class="block text-sm font-medium text-gray-700">Trạng thái:</label>
            <select name="status" id="status" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="active" <?php echo $ticket['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="inactive" <?php echo $ticket['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
            </select>
        </div>

        <div>
            <label for="current_image" class="block text-sm font-medium text-gray-700">Ảnh hiện tại:</label>
            <?php if ($ticket['image_path'] && file_exists('../' . $ticket['image_path'])): ?>
                <img src="../<?php echo htmlspecialchars($ticket['image_path']); ?>" alt="Current Ticket Image" class="mt-2 h-32 w-auto rounded-md object-cover">
            <?php else: ?>
                <p class="mt-2 text-sm text-gray-500">Chưa có ảnh.</p>
            <?php endif; ?>
        </div>

        <div class="flex justify-end">
             <button type="submit" class="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cập nhật vé tàu</button>
        </div>
    </form>
</div>

