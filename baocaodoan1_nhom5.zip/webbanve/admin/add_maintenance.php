<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Lấy danh sách tàu
$trains_query = "SELECT id, train_name, train_number FROM loaitau ORDER BY train_name";
$trains_stmt = $conn->query($trains_query);
$trains = $trains_stmt->fetchAll(PDO::FETCH_ASSOC);

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $schedule_time = $_POST['schedule_time'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    try {
        $insert_query = "INSERT INTO baoduong (train_id, schedule_time, description, status) 
                        VALUES (:train_id, :schedule_time, :description, :status)";
        $stmt = $conn->prepare($insert_query);
        $stmt->execute([
            ':train_id' => $train_id,
            ':schedule_time' => $schedule_time,
            ':description' => $description,
            ':status' => $status
        ]);

        $_SESSION['success'] = "Thêm lịch bảo dưỡng thành công!";
        header('Location: maintenance.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi thêm lịch bảo dưỡng: " . $e->getMessage();
    }
    header('Location: add_maintenance.php');
    exit();
}

include '../includes/admin_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Thêm lịch bảo dưỡng mới</h1>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
            <?php unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <div class="bg-white shadow-md rounded-lg p-6">
        <form action="add_maintenance.php" method="POST" class="space-y-4">
            <div>
                <label for="train_id" class="block text-sm font-medium text-gray-700">Chọn tàu:</label>
                <select name="train_id" id="train_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn tàu --</option>
                    <?php foreach ($trains as $train): ?>
                        <option value="<?php echo $train['id']; ?>">
                            <?php echo htmlspecialchars($train['train_name'] . ' (' . $train['train_number'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="schedule_time" class="block text-sm font-medium text-gray-700">Thời gian bảo dưỡng:</label>
                <input type="datetime-local" name="schedule_time" id="schedule_time" required 
                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Mô tả:</label>
                <textarea name="description" id="description" rows="3" 
                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
            </div>

            <div>
                <label for="status" class="block text-sm font-medium text-gray-700">Trạng thái:</label>
                <select name="status" id="status" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="scheduled">Đã lên lịch</option>
                    <option value="in_progress">Đang bảo dưỡng</option>
                    <option value="completed">Hoàn thành</option>
                    <option value="cancelled">Đã hủy</option>
                </select>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Thêm lịch bảo dưỡng
                </button>
            </div>
        </form>
    </div>
</div>

