<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}

// Xử lý xóa loại tàu
if (isset($_POST['delete_train_type'])) {
    $type_id = $_POST['type_id'];
    try {
        // Kiểm tra xem có tuyến đường nào đang sử dụng loại tàu này không
        $check_query = "SELECT COUNT(*) FROM tuyenduong WHERE train_id = :type_id";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->execute([':type_id' => $type_id]);
        $count = $check_stmt->fetchColumn();

        if ($count == 0) {
            // Nếu không có tuyến đường nào sử dụng, tiến hành xóa
            $delete_query = "DELETE FROM loaitau WHERE id = :type_id";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->execute([':type_id' => $type_id]);
            $_SESSION['success'] = "Xóa loại tàu thành công!";
        } else {
            // Nếu có tuyến đường sử dụng, báo lỗi
            $_SESSION['error'] = "Không thể xóa loại tàu vì có tuyến đường đang sử dụng.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi xóa loại tàu: " . $e->getMessage();
    }
    header('Location: train_types.php');
    exit();
}

// Lấy danh sách loại tàu từ database
$types_query = "SELECT * FROM loaitau ORDER BY train_name";
$types_stmt = $conn->query($types_query);
$train_types = $types_stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Quản lý loại tàu</h1>

<!-- Nút thêm mới -->
<div class="mb-4">
    <a href="add_train_type.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm loại tàu mới</a>
</div>

<!-- Messages -->
<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<!-- Bảng danh sách loại tàu -->
<div class="bg-white shadow-md rounded-lg overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tên loại tàu</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mã tàu</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mô tả</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($train_types as $type): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($type['id'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($type['train_name'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($type['train_number'] ?? ''); ?></td>
                     <td class="px-6 py-4 text-sm text-gray-900">
                         <div class="max-w-xs truncate">
                            <?php echo htmlspecialchars($type['description'] ?? ''); ?>
                         </div>
                     </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="edit_train_type.php?id=<?php echo htmlspecialchars($type['id'] ?? ''); ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Sửa</a>
                        <form method="POST" action="" class="inline-block" onsubmit="return confirm('Bạn có chắc chắn muốn xóa loại tàu này không?\nLưu ý: Chỉ có thể xóa loại tàu khi không có vé tàu nào sử dụng nó.');">
                            <input type="hidden" name="delete_train_type" value="1">
                            <input type="hidden" name="type_id" value="<?php echo htmlspecialchars($type['id'] ?? ''); ?>">
                            <button type="submit" class="text-red-600 hover:text-red-900">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

