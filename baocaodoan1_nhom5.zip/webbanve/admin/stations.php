<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}


// Xử lý xóa ga tàu
if (isset($_POST['delete_station'])) {
    $station_id = $_POST['station_id'];
    try {
        // Kiểm tra xem ga này có đang được sử dụng trong tuyenduong không
        $check_departure_query = "SELECT COUNT(*) FROM tuyenduong WHERE departure_station_id = :station_id";
        $check_departure_stmt = $conn->prepare($check_departure_query);
        $check_departure_stmt->execute([':station_id' => $station_id]);
        $count_departure = $check_departure_stmt->fetchColumn();

        $check_arrival_query = "SELECT COUNT(*) FROM tuyenduong WHERE arrival_station_id = :station_id";
        $check_arrival_stmt = $conn->prepare($check_arrival_query);
        $check_arrival_stmt->execute([':station_id' => $station_id]);
        $count_arrival = $check_arrival_stmt->fetchColumn();

        if ($count_departure == 0 && $count_arrival == 0) {
            // Nếu ga không được sử dụng, tiến hành xóa
            $delete_query = "DELETE FROM gatau WHERE id = :station_id";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->execute([':station_id' => $station_id]);
            $_SESSION['success'] = "Xóa ga tàu thành công!";
        } else {
            // Nếu ga đang được sử dụng, báo lỗi
            $_SESSION['error'] = "Không thể xóa ga tàu vì có tuyến đường đang sử dụng.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi xóa ga tàu: " . $e->getMessage();
    }
    header('Location: stations.php');
    exit();
}

// Lấy danh sách ga tàu từ database
$stations_query = "SELECT * FROM gatau ORDER BY city, station_name";
$stations_stmt = $conn->query($stations_query);
$stations = $stations_stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Quản lý ga tàu</h1>

<!-- Nút thêm mới -->
<div class="mb-4">
    <a href="add_station.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm ga tàu mới</a>
</div>

<!-- Messages -->
<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<!-- Bảng danh sách ga tàu -->
<div class="bg-white shadow-md rounded-lg overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tên ga</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thành phố</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Địa chỉ</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($stations as $station): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($station['id'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($station['station_name'] ?? ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($station['city'] ?? ''); ?></td>
                     <td class="px-6 py-4 text-sm text-gray-900">
                         <div class="max-w-xs truncate">
                            <?php echo htmlspecialchars($station['address'] ?? ''); ?>
                         </div>
                     </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="edit_station.php?id=<?php echo htmlspecialchars($station['id'] ?? ''); ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Sửa</a>
                        <form method="POST" action="" class="inline-block" onsubmit="return confirm('Bạn có chắc chắn muốn xóa ga tàu này không?\nLưu ý: Chỉ có thể xóa ga tàu khi không có tuyến đường nào sử dụng nó.');">
                            <input type="hidden" name="delete_station" value="1">
                            <input type="hidden" name="station_id" value="<?php echo htmlspecialchars($station['id'] ?? ''); ?>">
                            <button type="submit" class="text-red-600 hover:text-red-900">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

