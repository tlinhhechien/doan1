<?php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}


// Lấy danh sách Ga tàu và Loại tàu cho dropdown
$stations_query = "SELECT id, station_name, city FROM gatau ORDER BY city, station_name";
$stations_stmt = $conn->query($stations_query);
$stations = $stations_stmt->fetchAll(PDO::FETCH_ASSOC);

$train_types_query = "SELECT id, train_name, train_number FROM loaitau ORDER BY train_name";
$train_types_stmt = $conn->query($train_types_query);
$train_types = $train_types_stmt->fetchAll(PDO::FETCH_ASSOC);

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $departure_station_id = $_POST['departure_station_id'];
    $arrival_station_id = $_POST['arrival_station_id'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $price = $_POST['price'];
    $status = $_POST['status'];

    try {
        $insert_query = "INSERT INTO tuyenduong (train_id, departure_station_id, arrival_station_id, departure_time, arrival_time, price, status) 
                         VALUES (:train_id, :departure_station_id, :arrival_station_id, :departure_time, :arrival_time, :price, :status)";
        $stmt = $conn->prepare($insert_query);
        $stmt->execute([
            ':train_id' => $train_id,
            ':departure_station_id' => $departure_station_id,
            ':arrival_station_id' => $arrival_station_id,
            ':departure_time' => $departure_time,
            ':arrival_time' => $arrival_time,
            ':price' => $price,
            ':status' => $status
        ]);

        $_SESSION['success'] = "Thêm vé tàu thành công!";
        header('Location: tickets.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi thêm vé tàu: " . $e->getMessage();
    }
    header('Location: add_ticket.php');
    exit();
}

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Thêm vé tàu mới</h1>

<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<div class="bg-white shadow-md rounded-lg p-6">
    <form action="add_ticket.php" method="POST" class="space-y-4">
        <div>
            <label for="train_id" class="block text-sm font-medium text-gray-700">Loại tàu:</label>
            <select name="train_id" id="train_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="">-- Chọn loại tàu --</option>
                <?php foreach ($train_types as $type): ?>
                    <option value="<?php echo $type['id']; ?>"><?php echo htmlspecialchars($type['train_name'] . ' (' . $type['train_number'] . ')'); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label for="departure_station_id" class="block text-sm font-medium text-gray-700">Ga đi:</label>
                <select name="departure_station_id" id="departure_station_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn ga đi --</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>"><?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="arrival_station_id" class="block text-sm font-medium text-gray-700">Ga đến:</label>
                <select name="arrival_station_id" id="arrival_station_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">-- Chọn ga đến --</option>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?php echo $station['id']; ?>"><?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

         <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label for="departure_time" class="block text-sm font-medium text-gray-700">Thời gian đi:</label>
                <input type="time" name="departure_time" id="departure_time" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>
            <div>
                <label for="arrival_time" class="block text-sm font-medium text-gray-700">Thời gian đến:</label>
                <input type="time" name="arrival_time" id="arrival_time" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>
        </div>

        <div>
            <label for="price" class="block text-sm font-medium text-gray-700">Giá:</label>
            <input type="number" name="price" id="price" required min="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

         <div>
            <label for="status" class="block text-sm font-medium text-gray-700">Trạng thái:</label>
            <select name="status" id="status" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Thêm vé tàu</button>
        </div>
    </form>
</div>



