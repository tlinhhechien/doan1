<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
    header("Location: /webbanve/pages/login.php");
    exit();
}


// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_name = $_POST['train_name'];
    $train_number = $_POST['train_number'];
    $description = $_POST['description'];
    $total_seats = $_POST['total_seats'];

    try {
        $insert_query = "INSERT INTO loaitau (train_name, train_number, description, total_seats) VALUES (:train_name, :train_number, :description, :total_seats)";
        $stmt = $conn->prepare($insert_query);
        $stmt->execute([
            ':train_name' => $train_name,
            ':train_number' => $train_number,
            ':description' => $description,
            ':total_seats' => $total_seats
        ]);

        $_SESSION['success'] = "Thêm loại tàu thành công!";
        header('Location: train_types.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi khi thêm loại tàu: " . $e->getMessage();
    }
    // Nếu có lỗi, chuyển hướng về trang add_train_type.php để hiển thị lỗi
    header('Location: add_train_type.php');
    exit();
}

include '../includes/admin_header.php';
?>

<h1 class="text-2xl font-bold text-gray-800 mb-4">Thêm loại tàu mới</h1>

<?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['success']; ?></span>
        <?php unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo $_SESSION['error']; ?></span>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<div class="bg-white shadow-md rounded-lg p-6">
    <form action="add_train_type.php" method="POST" class="space-y-4">
        <div>
            <label for="train_name" class="block text-sm font-medium text-gray-700">Tên loại tàu:</label>
            <input type="text" name="train_name" id="train_name" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="train_number" class="block text-sm font-medium text-gray-700">Mã tàu:</label>
            <input type="text" name="train_number" id="train_number" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="total_seats" class="block text-sm font-medium text-gray-700">Tổng số ghế:</label>
            <input type="number" name="total_seats" id="total_seats" required min="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        </div>

        <div>
            <label for="description" class="block text-sm font-medium text-gray-700">Mô tả (Tùy chọn):</label>
            <textarea name="description" id="description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Thêm loại tàu</button>
        </div>
    </form>
</div>



