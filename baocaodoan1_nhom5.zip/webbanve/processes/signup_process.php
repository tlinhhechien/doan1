<?php
session_start();
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($username) || empty($email) || empty($password)) {
        $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin!";
        header("Location: ../pages/dangki.php");
        exit();
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Email không hợp lệ!";
        header("Location: ../pages/dangki.php");
        exit();
    } elseif (strlen($password) < 6) {
        $_SESSION['error'] = "Mật khẩu phải có ít nhất 6 ký tự!";
        header("Location: ../pages/dangki.php");
        exit();
    } else {
        try {
         $hashed_password = md5($password);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
            $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashed_password]);
            $_SESSION['success'] = "Đăng ký thành công! Vui lòng đăng nhập.";
            header("Location: ../pages/login.php");
            exit();
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Integrity constraint violation (duplicate entry)
                if (strpos($e->getMessage(), 'unique_username') !== false) {
                    $_SESSION['error'] = "Tên đăng nhập đã tồn tại!";
                } elseif (strpos($e->getMessage(), 'email') !== false) {
                    $_SESSION['error'] = "Email đã tồn tại!";
                } else {
                    $_SESSION['error'] = "Có lỗi xảy ra, vui lòng thử lại!";
                }
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra: " . $e->getMessage();
            }
            header("Location: ../pages/dangki.php");
            exit();
        }
    }
}
?>