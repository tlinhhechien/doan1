<?php
session_start();
include '../includes/config.php';

// kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['username'])) {
    $_SESSION['error'] = "Vui lòng đăng nhập để đổi mật khẩu.";
    header("Location: ../pages/login.php");
    exit();
}

// Xử lý việc gửi biểu mẫu
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $username = $_SESSION['username'];

  
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $_SESSION['error'] = "Vui lòng điền đầy đủ các trường.";
        header("Location: ../pages/doimatkhau.php");
        exit();
    }

    if ($new_password !== $confirm_password) {
        $_SESSION['error'] = "Mật khẩu mới và xác nhận mật khẩu không khớp.";
        header("Location: ../pages/doimatkhau.php");
        exit();
    }

    if (strlen($new_password) < 8) {
        $_SESSION['error'] = "Mật khẩu mới phải có ít nhất 8 ký tự.";
        header("Location: ../pages/doimatkhau.php");
        exit();
    }

    // Sử dụng kết nối từ config.php ($conn)
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['error'] = "Tài khoản không tồn tại.";
        header("Location: ../pages/doimatkhau.php");
        exit();
    }

    $stored_password = $user['password'];

    if (!password_verify($current_password, $stored_password)) {
        $_SESSION['error'] = "Mật khẩu hiện tại không đúng.";
        header("Location: ../pages/doimatkhau.php");
        exit();
    }

    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE users SET password = :password WHERE username = :username");
    
    if ($stmt->execute(['password' => $new_password_hash, 'username' => $username])) {
        $_SESSION['success'] = "Đổi mật khẩu thành công.";
    } else {
        $_SESSION['error'] = "Đổi mật khẩu thất bại. Vui lòng thử lại.";
    }

    header("Location: ../pages/doimatkhau.php");
    exit();
}
?>