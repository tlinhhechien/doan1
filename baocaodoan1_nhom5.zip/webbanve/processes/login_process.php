<?php
session_start();
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username_or_email = trim($_POST['username']); // Có thể là email hoặc username
    $password = trim($_POST['password']);

    // Truy vấn: tìm theo username hoặc email
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :input OR email = :input");
    $stmt->execute(['input' => $username_or_email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['error'] = "Tên đăng nhập hoặc email không tồn tại!";
        header("Location: ../pages/login.php");
        exit();
    } elseif (md5($password) !== $user['password']) {
        $_SESSION['error'] = "Mật khẩu không đúng!";
        header("Location: ../pages/login.php");
        exit();
    } else {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['success'] = "Đăng nhập thành công!";
        if ($user['role'] == 'admin'){
            header("Location: ../admin/index.php");
        } else {
            header("Location: ../index.php");
        }
        exit();
    }
}
?>
