<?php
require_once 'includes/config.php';
require_once 'includes/header.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Vui lòng đăng nhập để đặt vé";
    header("Location: pages/login.php");
    exit();
}

// Lấy thông tin vé
$ticket_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Query để lấy thông tin vé
$ticket_query = "SELECT t.*, 
    l.train_name, l.train_number,
    g1.station_name as departure_station, g1.city as departure_city,
    g2.station_name as arrival_station, g2.city as arrival_city
    FROM tuyenduong t
    JOIN loaitau l ON t.train_id = l.id
    JOIN gatau g1 ON t.departure_station_id = g1.id
    JOIN gatau g2 ON t.arrival_station_id = g2.id
    WHERE t.id = :ticket_id AND t.status = 'active'";

$ticket_stmt = $conn->prepare($ticket_query);
$ticket_stmt->execute([':ticket_id' => $ticket_id]);
$ticket = $ticket_stmt->fetch(PDO::FETCH_ASSOC);

if (!$ticket) {
    header("Location: dat-ve.php");
    exit();
}

// Xử lý đặt vé
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $number_of_tickets = isset($_POST['number_of_tickets']) ? intval($_POST['number_of_tickets']) : 0;
    
    if ($number_of_tickets > 0 && $number_of_tickets <= 4) {
        $total_amount = $ticket['price'] * $number_of_tickets;
        
        // Thêm đơn đặt vé
        $booking_query = "INSERT INTO datve (user_id, route_id, booking_date, number_of_tickets, total_amount, status) 
                         VALUES (:user_id, :route_id, :booking_date, :number_of_tickets, :total_amount, 'pending')";
        
        $booking_stmt = $conn->prepare($booking_query);
        $result = $booking_stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':route_id' => $ticket_id,
            ':booking_date' => $date,
            ':number_of_tickets' => $number_of_tickets,
            ':total_amount' => $total_amount
        ]);
        
        if ($result) {
            $booking_id = $conn->lastInsertId();
            header("Location: checkout.php?id=" . $booking_id);
            exit();
        } else {
            $error = "Có lỗi xảy ra khi đặt vé. Vui lòng thử lại.";
        }
    } else {
        $error = "Số lượng vé không hợp lệ. Vui lòng chọn từ 1 đến 4 vé.";
    }
}
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <!-- Thông tin vé -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-2xl font-bold text-[#003366] mb-4">Thông tin chuyến tàu</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 class="text-xl font-semibold text-[#003366]"><?php echo htmlspecialchars($ticket['train_name']); ?></h3>
                    <p class="text-gray-600">Mã tàu: <?php echo htmlspecialchars($ticket['train_number']); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-2xl font-bold text-[#003366]"><?php echo number_format($ticket['price'], 0, ',', '.'); ?> đ</p>
                    <p class="text-gray-600">Giá vé một chiều</p>
                </div>
            </div>
            
            <div class="mt-6 flex flex-col md:flex-row justify-between items-start md:items-center">
                <div class="text-center mb-4 md:mb-0">
                    <p class="font-semibold"><?php echo htmlspecialchars($ticket['departure_station']); ?></p>
                    <p class="text-gray-600"><?php echo htmlspecialchars($ticket['departure_city']); ?></p>
                    <p class="text-[#003366]"><?php echo date('H:i', strtotime($ticket['departure_time'])); ?></p>
                </div>
                <div class="hidden md:block">
                    <div class="w-32 h-0.5 bg-gray-300"></div>
                    <p class="text-center text-sm text-gray-500 mt-1">
                        <?php 
                        $departure = new DateTime($ticket['departure_time']);
                        $arrival = new DateTime($ticket['arrival_time']);
                        $interval = $departure->diff($arrival);
                        echo $interval->format('%Hh%ip');
                        ?>
                    </p>
                </div>
                <div class="text-center">
                    <p class="font-semibold"><?php echo htmlspecialchars($ticket['arrival_station']); ?></p>
                    <p class="text-gray-600"><?php echo htmlspecialchars($ticket['arrival_city']); ?></p>
                    <p class="text-[#003366]"><?php echo date('H:i', strtotime($ticket['arrival_time'])); ?></p>
                </div>
            </div>
        </div>

        <!-- Form đặt vé -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold text-[#003366] mb-4">Đặt vé</h2>
            
            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST" class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Ngày đi</label>
                    <input type="date" value="<?php echo $date; ?>" disabled
                        class="w-full rounded-md border-gray-300 bg-gray-100 shadow-sm">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Số lượng vé</label>
                    <select name="number_of_tickets" required
                        class="w-full rounded-md border-gray-300 shadow-sm focus:border-[#003366] focus:ring focus:ring-[#003366] focus:ring-opacity-50">
                        <?php for ($i = 1; $i <= 4; $i++): ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?> vé</option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tổng tiền</label>
                    <p class="text-2xl font-bold text-[#003366]" id="total-amount">
                        <?php echo number_format($ticket['price'], 0, ',', '.'); ?> đ
                    </p>
                </div>

                <button type="submit" class="w-full bg-[#003366] text-white py-3 px-6 rounded-md hover:bg-[#002244] transition duration-300">
                    Tiếp tục
                </button>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelector('select[name="number_of_tickets"]').addEventListener('change', function() {
    const price = <?php echo $ticket['price']; ?>;
    const quantity = parseInt(this.value);
    const total = price * quantity;
    document.getElementById('total-amount').textContent = total.toLocaleString('vi-VN') + ' đ';
});
</script>

<?php require_once 'includes/footer.php'; ?> 