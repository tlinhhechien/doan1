<?php
require_once 'includes/config.php'; // Đảm bảo đã kết nối PDO

// Lấy danh sách ga tàu
$stations_query = "SELECT * FROM gatau ORDER BY city, station_name";
$stations_stmt = $conn->query($stations_query);
$stations = $stations_stmt->fetchAll(PDO::FETCH_ASSOC);

// Nếu có dùng biến $from_station, $to_station thì cũng nên khởi tạo:
$from_station = isset($_GET['from']) ? $_GET['from'] : '';
$to_station = isset($_GET['to']) ? $_GET['to'] : '';
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Truy vấn các chuyến tàu phổ biến từ database
$popular_query = "
    SELECT t.*, 
        l.train_name, l.train_number,
        g1.station_name AS departure_station, g1.city AS departure_city,
        g2.station_name AS arrival_station, g2.city AS arrival_city
    FROM tuyenduong t
    JOIN loaitau l ON t.train_id = l.id
    JOIN gatau g1 ON t.departure_station_id = g1.id
    JOIN gatau g2 ON t.arrival_station_id = g2.id
    WHERE t.status = 'active'
    ORDER BY t.id DESC
    LIMIT 8
";
$popular_stmt = $conn->query($popular_query);
$popular_routes = $popular_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include 'includes/header.php'; ?>
  <!-- Banner Section -->
  <section class="relative max-w-[1200px] mx-auto mt-4 rounded-md overflow-hidden" style="max-height: 280px">
   <img alt="Train on railway track with green field and trees in background, bright sunny day" class="w-full object-cover h-[280px]" height="280" src="assets/images/de8546c8-29ed-441c-1a0f-611414b25f0e.jpg" width="1200"/>
   <div class="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center px-4 md:px-8">
    <div class="max-w-[900px] bg-[#003366cc] rounded-md p-4 md:p-6">
     <h2 class="text-white font-bold text-lg md:text-xl mb-2">
      Đặt vé tàu hỏa online
     </h2>
     <div class="flex flex-wrap gap-2 mb-3 text-xs md:text-sm">
      <div class="bg-[#ff6f6f] rounded px-2 py-0.5 flex items-center gap-1">
       <i class="fas fa-exclamation-triangle text-white text-[10px]">
       </i>
       <span class="text-white font-semibold">
        Đường sắt Việt Nam 
       </span>
      </div>
      <div class="bg-[#2e9e7e] rounded px-2 py-0.5 flex items-center gap-1">
       <i class="fas fa-clock text-white text-[10px]">
       </i>
       <span class="text-white font-semibold">
        Chất lượng trong mọi khung đường
       </span>
      </div>
     </div>
     <form action="pages/dat-ve.php" method="GET" class="bg-[#003366cc] rounded-md p-3 md:p-4 grid grid-cols-1 md:grid-cols-5 gap-3 md:gap-4 items-center">
      <div>
       <label class="block text-sm font-medium mb-1 text-[#fff]">Ga đi</label>
       <select name="from" required class="w-full rounded border border-gray-300 text-sm px-2 py-1">
        <option value="">Chọn ga đi</option>
        <?php foreach ($stations as $station): ?>
         <option value="<?php echo $station['id']; ?>" <?php echo $from_station == $station['id'] ? 'selected' : ''; ?>>
          <?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?>
         </option>
        <?php endforeach; ?>
       </select>
      </div>
      <div>
       <label class="block text-sm font-medium mb-1 text-[#fff]">Ga đến</label>
       <select name="to" required class="w-full rounded border border-gray-300 text-sm px-2 py-1">
        <option value="">Chọn ga đến</option>
        <?php foreach ($stations as $station): ?>
         <option value="<?php echo $station['id']; ?>" <?php echo $to_station == $station['id'] ? 'selected' : ''; ?>>
          <?php echo htmlspecialchars($station['station_name'] . ' (' . $station['city'] . ')'); ?>
         </option>
        <?php endforeach; ?>
       </select>
      </div>
      <div>
       <label class="block text-sm font-medium mb-1 text-[#fff]">Loại tàu</label>
       <select name="train_type" class="w-full rounded border border-gray-300 text-sm px-2 py-1">
        <option value="">Tất cả loại tàu</option>
        <?php
        $train_types_query = "SELECT * FROM loaitau ORDER BY train_name";
        $train_types_stmt = $conn->query($train_types_query);
        $train_types = $train_types_stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($train_types as $type):
        ?>
         <option value="<?php echo $type['id']; ?>">
          <?php echo htmlspecialchars($type['train_name']); ?>
         </option>
        <?php endforeach; ?>
       </select>
      </div>
      <div>
       <label class="block text-sm font-medium mb-1 text-[#ffff]">Ngày đi</label>
       <input type="date" name="date" value="<?php echo $date; ?>" min="<?php echo date('Y-m-d'); ?>" 
        class="w-full rounded border border-gray-300 text-sm px-2 py-1">
      </div>
      <div class="flex items-end">
       <button type="submit" class="bg-[#ff8c00] hover:bg-[#e07b00] text-white font-semibold text-sm rounded px-4 py-2 w-full">
        Tìm chuyến tàu
       </button>
      </div>
     </form>
    </div>
    <div class="absolute top-6 right-6 bg-[#003366cc] rounded-md p-3 text-[#ff8c00] text-xs md:text-sm max-w-[220px]">
     <div class="font-bold mb-1">
      TÀU HỎA 20 TOA HẠNG SANG
     </div>
     <div class="font-semibold text-white mb-1">
      Hà Nội – Hải Phòng
     </div>
     <div class="flex items-center space-x-1 cursor-pointer text-white font-semibold">
      <span>
       Đặt vé ngay - Nhận ưu đãi
      </span>
      <i class="fas fa-chevron-right text-xs">
      </i>
     </div>
     <div class="mt-2 flex space-x-2">
      <img alt="Interior train seat with red upholstery and window view" class="rounded" height="60" src="assets/images/31bfe303-bc52-4099-9227-c88f5e0d8049.jpg" width="60"/>
      <img alt="Train interior with seats and tables, warm lighting" class="rounded" height="60" src="assets/images/df2c8529-29ec-4f01-d991-be1ea1208316.jpg" width="60"/>
     </div>
    </div>
   </div>
  </section>
  
  <!-- Features -->
  <!--<section class="max-w-[1200px] mx-auto mt-6 px-4 md:px-0">
   <ul class="flex flex-col md:flex-row justify-between text-xs md:text-sm text-[#003366] font-semibold">
    <li class="flex items-center space-x-2 mb-3 md:mb-0">
     <i class="fas fa-check text-[#003366]">
     </i>
     <span>
      Tìm chuyến tàu phù hợp
     </span>
     <span class="text-[#999] ml-1">
      Lựa chọn lịch trình linh hoạt
     </span>
    </li>
    <li class="flex items-center space-x-2 mb-3 md:mb-0">
     <i class="fas fa-ticket-alt text-[#003366]">
     </i>
     <span>
      Đặt vé nhanh, dễ dàng
     </span>
     <span class="text-[#999] ml-1">
      Nhận vé ngay sau khi đặt
     </span>
    </li>
    <li class="flex items-center space-x-2">
     <i class="fas fa-headset text-[#003366]">
     </i>
     <span>
      Luôn sẵn sàng hỗ trợ
     </span>
     <span class="text-[#999] ml-1">
      Phản hồi trong 15 phút qua điện thoại, zalo
     </span>
    </li>
   </ul>
  </section> -->

  <!-- Map Section -->
  <section class="max-w-[1200px] mx-auto mt-8 px-4 md:px-0">
   <h3 class="text-[#333] font-semibold text-lg mb-1">
    Bản đồ tuyến đường sắt Việt Nam
   </h3>
   <p class="text-[#666] text-xs md:text-sm mb-4">
    Xem thông tin chi tiết về các tuyến tàu hỏa, lịch trình và điểm dừng
   </p>
   <div class="bg-[#d9e9f9] rounded-md p-4 md:p-6 flex flex-col md:flex-row gap-6">
    <div class="flex-shrink-0 max-w-[600px] md:max-w-none md:flex-1">
     <img alt="Bản đồ tuyến đường sắt Việt Nam với các ga và tuyến đường được đánh dấu màu sắc khác nhau" class="w-full rounded-md" height="500" src="assets/images/map.webp" width="600"/>
    </div>
    <div class="text-xs md:text-sm text-[#003366] flex-1 leading-tight">
     <div class="mb-3">
      <strong>
       Đường sắt Bắc - Nam
      </strong>
      <br/>
      Hà Nội - Sài Gòn
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE1
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE3
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE5
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE7
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       TN1
      </span>
     </div>
     <div class="mb-3">
      <strong>
       Đường sắt Hà Nội
      </strong>
      <br/>
      Hà Nội - Đà Nẵng
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE19
      </span>
      Hà Nội - Vinh - Đồng Hới - Huế
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       NA1
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       NA2
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE11
      </span>
      Hà Nội - Lào Cai
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LP3
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LP5
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LF7
      </span>
      Hà Nội - Hải Phòng
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       D71
      </span>
      Hà Nội - Thái Nguyên
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       D70
      </span>
      Hà Nội - Đồng Đăng
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LP1
      </span>
      Kép - Hạ Long
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LP2
      </span>
     </div>
     <div class="mb-3">
      <strong>
       Đường sắt Sài Gòn
      </strong>
      <br/>
      Sài Gòn - Huế
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE4
      </span>
      Sài Gòn - Quy Nhơn
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE6
      </span>
      Sài Gòn - Nha Trang - Tuy Hòa
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SE8
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       NT1
      </span>
      Sài Gòn - Phan Thiết
      <br/>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       SP11
      </span>
      <span class="inline-block bg-[#003366] text-white rounded px-1 py-[1px] text-[10px] mr-1">
       LP3
      </span>
     </div>
    </div>
   </div>
  </section>
  <!-- Popular routes -->
  <section class="max-w-[1200px] mx-auto mt-8 px-4 md:px-0">
   <h3 class="text-[#333] font-semibold text-lg mb-1">
    Các hành trình tàu hỏa phổ biến
   </h3>
   <p class="text-[#666] text-xs md:text-sm mb-4">
    Khám phá những tuyến đường được yêu thích nhất và đặt vé ngay với giá ưu đãi!
   </p>
   <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <?php foreach ($popular_routes as $route): ?>
    <div class="bg-white rounded-md p-3 shadow-sm text-xs md:text-sm">
        <div class="text-[#003366] font-semibold mb-1 text-[10px] md:text-xs">
            <?php echo htmlspecialchars($route['train_name']); ?> (<?php echo htmlspecialchars($route['train_number']); ?>)
        </div>
        <div class="flex justify-between text-[#666] mb-1">
            <span><?php echo htmlspecialchars($route['departure_station']); ?></span>
            <span>
                <?php
                $departure = new DateTime($route['departure_time']);
                $arrival = new DateTime($route['arrival_time']);
                $interval = $departure->diff($arrival);
                echo $interval->format('%Hh%Ip');
                ?>
            </span>
            <span><?php echo htmlspecialchars($route['arrival_station']); ?></span>
        </div>
        <div class="text-[#0099ff] font-semibold mb-2">
            <?php echo number_format($route['price'], 0, ',', '.'); ?> đ
        </div>
        <a href="pages/dat-ve.php?from=<?php echo $route['departure_station_id']; ?>&to=<?php echo $route['arrival_station_id']; ?>&date=<?php echo date('Y-m-d'); ?>" class="bg-[#ff8c00] text-white text-xs md:text-sm rounded px-3 py-1 hover:bg-[#e07b00] w-full block text-center">
            Xem
        </a>
    </div>
    <?php endforeach; ?>
   </div>
  </section>
  <!-- Train travel news -->
  <!-- FAQ Section -->
  <!-- Customer reviews -->
  <!-- <section class="max-w-[1200px] mx-auto mt-8 px-4 md:px-0">
   <h3 class="text-[#333] font-semibold text-lg mb-1">
    Đánh giá của khách hàng sử dụng dịch vụ đặt vé tàu hỏa Đường sắt Việt Nam
   </h3>
   <div class="inline-block bg-[#2e9e7e] text-white text-xs rounded px-2 py-0.5 font-semibold mb-3">
    9.6/10
   </div>
   <span class="text-xs text-[#666] mb-3 inline-block">
    Tuyệt vời | 37 đánh giá
   </span>
   <div class="flex overflow-x-auto scrollbar-hide space-x-2 mb-4">
    <img alt="Customer review image 1 showing train and passengers" class="rounded" height="40" src="assets/images/0ae004ac-d565-4c7b-e4aa-4b193a863786.jpg" width="60"/>
    <img alt="Customer review image 2 showing train station and people" class="rounded" height="40" src="assets/images/b30a6754-ba21-43a0-cedd-5423a960f7dd.jpg" width="60"/>
    <img alt="Customer review image 3 showing train exterior and landscape" class="rounded" height="40" src="assets/images/f524bff7-6503-49f8-1c9e-66952c634c0b.jpg" width="60"/>
    <img alt="Customer review image 4 showing train interior and seats" class="rounded" height="40" src="assets/images/1041e494-a4bc-4f5f-07c3-40748f529440.jpg" width="60"/>
    <img alt="Customer review image 5 showing train platform and passengers" class="rounded" height="40" src="assets/images/7a27790f-c77d-4308-ac2e-568bdc85b96d.jpg" width="60"/>
    <img alt="Customer review image 6 showing train ticket and booking" class="rounded" height="40" src="assets/images/d109c0a8-5461-4aa1-c655-7b5a43affdc9.jpg" width="60"/>
    <img alt="Customer review image 7 showing train and countryside" class="rounded" height="40" src="assets/images/cebbb9a9-e88d-4f8c-2f3c-0906f63ec845.jpg" width="60"/>
    <img alt="Customer review image 8 showing train station and people" class="rounded" height="40" src="assets/images/d18d91e4-ec1b-431f-f229-3351ba190155.jpg" width="60"/>
    <img alt="Button to view 5 more customer review images" class="rounded cursor-pointer" height="40" src="assets/images/7ee2d2f7-ac3d-43d8-2805-894e94a09ecc.jpg" width="60"/>
   </div>
   <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs md:text-sm text-[#333]">
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      GL
     </div>
     <div>
      <div class="font-semibold">
       Lã Thị Gấm
      </div>
      <div class="text-[#666] text-xs">
       21-05-2025
      </div>
     </div>
    </div>
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      TN
     </div>
     <div>
      <div class="font-semibold">
       Nguyễn Ngọc Tài
      </div>
      <div class="text-[#666] text-xs">
       18-05-2025
      </div>
     </div>
    </div>
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      GN
     </div>
     <div>
      <div class="font-semibold">
       Nguyễn Hoàng Gia
      </div>
      <div class="text-[#666] text-xs">
       13-05-2025
      </div>
     </div>
    </div>
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      KN
     </div>
     <div>
      <div class="font-semibold">
       Nguyễn Thị Khuê
      </div>
      <div class="text-[#666] text-xs">
       13-05-2025
      </div>
     </div>
    </div>
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      TT
     </div>
     <div>
      <div class="font-semibold">
       Trần Chi Thông
      </div>
      <div class="text-[#666] text-xs">
       13-05-2025
      </div>
      <div class="text-[#666] text-xs">
       Tốt
      </div>
     </div>
    </div>
    <div class="bg-white rounded border border-gray-300 p-3 flex items-center space-x-3">
     <div class="flex items-center justify-center w-8 h-8 rounded-full bg-[#2e9e7e] text-white font-semibold text-xs">
      NN
     </div>
     <div>
      <div class="font-semibold">
       Nguyễn Ngọc Nam
      </div>
      <div class="text-[#666] text-xs">
       06-05-2025
      </div>
     </div>
    </div>
   </div>
  </section> -->
  <!-- Footer -->

  <?php
    include 'includes/footer.php'; ?>
