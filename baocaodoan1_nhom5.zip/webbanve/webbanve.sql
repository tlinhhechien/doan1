-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 25, 2025 lúc 08:18 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `webbanve`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `baoduong`
--

CREATE TABLE `baoduong` (
  `id` int(11) NOT NULL,
  `train_id` int(11) NOT NULL,
  `schedule_time` datetime NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `baoduong`
--

INSERT INTO `baoduong` (`id`, `train_id`, `schedule_time`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '2025-05-25 19:31:00', 'Nâng cấp chỗ ngồi', 'scheduled', '2025-05-24 12:32:28', '2025-05-24 12:32:28'),
(2, 2, '2025-05-25 20:41:00', 'Lịch bảo dưỡng', 'scheduled', '2025-05-24 13:41:59', '2025-05-24 13:41:59'),
(3, 2, '2025-05-27 02:45:00', 'Sửa chữa động cơ', 'completed', '2025-05-24 19:45:44', '2025-05-25 05:03:53');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('pending','processed','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `message`, `status`, `created_at`) VALUES
(1, 'Lê Tuấn Linh', 'tlinh@gmail.com', '0346202180', 'Trải nghiệm rất tuyệt', 'completed', '2025-05-24 12:21:25'),
(2, 'Lê Tuấn Linh', 'tlinh@gmail.com', '0346202180', 'Tàu chạy êm', 'pending', '2025-05-24 19:39:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `datve`
--

CREATE TABLE `datve` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `route_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `number_of_tickets` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `datve`
--

INSERT INTO `datve` (`id`, `user_id`, `phone`, `route_id`, `booking_date`, `number_of_tickets`, `total_amount`, `status`, `admin_note`, `created_at`) VALUES
(4, 2, NULL, 2, '2025-05-24', 1, 1000000.00, 'confirmed', NULL, '2025-05-24 12:15:57'),
(5, 2, NULL, 7, '2025-05-24', 1, 600000.00, 'confirmed', NULL, '2025-05-24 12:17:37'),
(6, 2, NULL, 6, '2025-05-24', 1, 400000.00, 'confirmed', NULL, '2025-05-24 12:18:02'),
(7, 1, NULL, 5, '2025-05-24', 1, 400000.00, 'confirmed', NULL, '2025-05-24 13:54:26'),
(8, 1, NULL, 13, '2025-05-24', 1, 200000.00, 'confirmed', NULL, '2025-05-24 13:58:17'),
(9, 1, '0898147807', 1, '2025-05-24', 1, 1000000.00, 'confirmed', NULL, '2025-05-24 14:13:16'),
(10, 2, '0346202180', 2, '2025-05-24', 1, 1000000.00, 'confirmed', NULL, '2025-05-24 19:36:57'),
(11, 5, '0898147807', 3, '2025-05-25', 2, 1000000.00, 'confirmed', NULL, '2025-05-25 04:43:07');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gatau`
--

CREATE TABLE `gatau` (
  `id` int(11) NOT NULL,
  `station_code` varchar(10) NOT NULL,
  `station_name` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `gatau`
--

INSERT INTO `gatau` (`id`, `station_code`, `station_name`, `city`, `address`, `created_at`) VALUES
(1, 'SGN', 'Ga Sài Gòn', 'Hồ Chí Minh', '1 Nguyễn Thông, Quận 3, TP.HCM', '2025-05-22 02:12:08'),
(2, 'HAN', 'Ga Hà Nội', 'Hà Nội', '120 Lê Duẩn, Đống Đa, Hà Nội', '2025-05-22 02:12:08'),
(3, 'DNG', 'Ga Đà Nẵng', 'Đà Nẵng', '202 Hải Phòng, Hải Châu, Đà Nẵng', '2025-05-22 02:12:08'),
(4, 'HUI', 'Ga Huế', 'Thừa Thiên Huế', '2 Bùi Thị Xuân, TP. Huế', '2025-05-22 02:12:08'),
(5, 'NHA', 'Ga Nha Trang', 'Khánh Hòa', '17 Thái Nguyên, TP. Nha Trang', '2025-05-22 02:12:08'),
(7, 'LP3', 'Hải phòng', 'Hải Phòng', 'Thành phố hải phòng', '2025-05-24 13:57:10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaitau`
--

CREATE TABLE `loaitau` (
  `id` int(11) NOT NULL,
  `train_number` varchar(20) NOT NULL,
  `train_name` varchar(100) NOT NULL,
  `total_seats` int(11) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `loaitau`
--

INSERT INTO `loaitau` (`id`, `train_number`, `train_name`, `total_seats`, `status`, `created_at`, `description`) VALUES
(1, 'SE1', 'Tàu nhanh chất lượng SE1', 500, 'active', '2025-05-22 02:12:08', NULL),
(2, 'SE2', 'Tàu nhanh chất lượng SE2', 500, 'active', '2025-05-22 02:12:08', NULL),
(3, 'SE3', 'Tàu nhanh chất lượng SE3', 500, 'active', '2025-05-22 02:12:08', NULL),
(4, 'SE4', 'Tàu nhanh chất lượng SE4', 500, 'active', '2025-05-22 02:12:08', NULL),
(5, 'SE5', 'Tàu nhanh chất lượng SE5', 500, 'active', '2025-05-22 02:12:08', NULL),
(6, 'SE6', 'Tàu nhanh chất lượng SE6', 500, 'active', '2025-05-22 02:12:08', NULL),
(8, 'LP3', 'LP3 chất lượng cao ', 24, 'active', '2025-05-24 13:56:35', 'dsssssdddddddddddd');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tuyenduong`
--

CREATE TABLE `tuyenduong` (
  `id` int(11) NOT NULL,
  `train_id` int(11) NOT NULL,
  `departure_station_id` int(11) NOT NULL,
  `arrival_station_id` int(11) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tuyenduong`
--

INSERT INTO `tuyenduong` (`id`, `train_id`, `departure_station_id`, `arrival_station_id`, `departure_time`, `arrival_time`, `price`, `status`, `created_at`, `image_path`) VALUES
(1, 1, 1, 2, '06:00:00', '15:26:00', 1000000.00, 'active', '2025-05-22 02:12:08', NULL),
(2, 2, 2, 1, '06:00:00', '15:26:00', 1000000.00, 'active', '2025-05-22 02:12:08', NULL),
(3, 3, 1, 3, '06:00:00', '08:30:00', 500000.00, 'active', '2025-05-22 02:12:08', NULL),
(4, 4, 3, 1, '06:00:00', '08:30:00', 500000.00, 'active', '2025-05-22 02:12:08', NULL),
(5, 5, 1, 4, '06:00:00', '07:15:00', 400000.00, 'active', '2025-05-22 02:12:08', NULL),
(6, 6, 4, 1, '06:00:00', '07:15:00', 400000.00, 'active', '2025-05-22 02:12:08', NULL),
(7, 1, 1, 5, '06:00:00', '09:45:00', 600000.00, 'active', '2025-05-22 02:12:08', NULL),
(8, 2, 5, 1, '06:00:00', '09:45:00', 600000.00, 'active', '2025-05-22 02:12:08', NULL),
(9, 3, 2, 3, '06:00:00', '09:30:00', 500000.00, 'active', '2025-05-22 02:12:08', NULL),
(10, 4, 3, 2, '06:00:00', '09:30:00', 500000.00, 'active', '2025-05-22 02:12:08', NULL),
(11, 5, 2, 4, '06:00:00', '08:15:00', 400000.00, 'active', '2025-05-22 02:12:08', NULL),
(12, 6, 4, 2, '06:00:00', '08:15:00', 400000.00, 'active', '2025-05-22 02:12:08', NULL),
(13, 8, 2, 7, '19:30:00', '20:39:00', 200000.00, 'active', '2025-05-24 13:57:55', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '70b4269b412a8af42b1f7b0d26eceff2', 'admin', '2025-05-24 12:10:13'),
(2, 'linh', 'tlinh@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'user', '2025-05-24 12:10:13'),
(5, 'dai', 'dai@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'user', '2025-05-24 12:33:14'),
(6, 'user1', 'user1@gmail.com', '89e7e39956d685b0970cf6397e62938d', 'user', '2025-05-24 13:35:52');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `baoduong`
--
ALTER TABLE `baoduong`
  ADD PRIMARY KEY (`id`),
  ADD KEY `train_id` (`train_id`);

--
-- Chỉ mục cho bảng `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `datve`
--
ALTER TABLE `datve`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `route_id` (`route_id`);

--
-- Chỉ mục cho bảng `gatau`
--
ALTER TABLE `gatau`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `station_code` (`station_code`);

--
-- Chỉ mục cho bảng `loaitau`
--
ALTER TABLE `loaitau`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `train_number` (`train_number`);

--
-- Chỉ mục cho bảng `tuyenduong`
--
ALTER TABLE `tuyenduong`
  ADD PRIMARY KEY (`id`),
  ADD KEY `train_id` (`train_id`),
  ADD KEY `departure_station_id` (`departure_station_id`),
  ADD KEY `arrival_station_id` (`arrival_station_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `baoduong`
--
ALTER TABLE `baoduong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `datve`
--
ALTER TABLE `datve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `gatau`
--
ALTER TABLE `gatau`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `loaitau`
--
ALTER TABLE `loaitau`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `tuyenduong`
--
ALTER TABLE `tuyenduong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `baoduong`
--
ALTER TABLE `baoduong`
  ADD CONSTRAINT `baoduong_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `loaitau` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `datve`
--
ALTER TABLE `datve`
  ADD CONSTRAINT `datve_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `datve_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `tuyenduong` (`id`);

--
-- Các ràng buộc cho bảng `tuyenduong`
--
ALTER TABLE `tuyenduong`
  ADD CONSTRAINT `tuyenduong_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `loaitau` (`id`),
  ADD CONSTRAINT `tuyenduong_ibfk_2` FOREIGN KEY (`departure_station_id`) REFERENCES `gatau` (`id`),
  ADD CONSTRAINT `tuyenduong_ibfk_3` FOREIGN KEY (`arrival_station_id`) REFERENCES `gatau` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
