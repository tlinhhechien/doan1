    </main>
    <!-- Footer -->
    <footer class=" max-w-[1200px] bg-[#003366] text-white mx-auto mt-3">
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-lg font-semibold mb-4">Về chúng tôi</h3>
                    <p class="text-gray-300">Hệ thống đặt vé tàu trực tuyến, mang đến cho bạn trải nghiệm đặt vé nhanh chóng và tiện lợi.</p>
                </div>
                <div>
                    <h3 class="text-lg font-semibold mb-4">Liên hệ</h3>
                    <p class="text-gray-300">Email: nhom5@gmail.com</p>
                    <p class="text-gray-300">Hotline: 1900 1234</p>
                </div>
                <div>
                    <h3 class="text-lg font-semibold mb-4">Theo dõi chúng tôi</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-300 hover:text-white">Facebook</a>
                        <a href="#" class="text-gray-300 hover:text-white">Twitter</a>
                        <a href="#" class="text-gray-300 hover:text-white">Instagram</a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
                <p>&copy; <?php echo date('Y'); ?> Đặt vé tàu. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
