<?php
// Khởi tạo session
include 'config.php'; // Kết nối database
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <base href="/webbanve/">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt vé tàu hỏa online - Đường sắt Việt Nam</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
</head>
<body class="bg-gray-100">
    <script src="assets/js/script.js"></script>
    <!-- Header Navigation -->
    <header class="bg-white shadow-sm">
        <nav class="max-w-[1200px] mx-auto px-4 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="text-[#003366] font-bold text-lg">Đường sắt Việt Nam</a>
                    <div class="hidden md:flex space-x-4">
                        <a href="index.php" class="text-[#666] hover:text-[#003366]">Trang chủ</a>
                        <a href="pages/dat-ve.php" class="text-[#666] hover:text-[#003366]">Đặt vé</a>
                        <a href="pages/baoduong.php" class="text-[#666] hover:text-[#003366]">Lịch bảo dưỡng tàu</a>
                        <a href="pages/contact.php" class="text-[#666] hover:text-[#003366]">Liên hệ</a>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="#" class="text-[#666] hover:text-[#003366]">
                        <i class="fas fa-phone-alt"></i>
                        <span class="hidden md:inline ml-1">0346273468</span>
                    </a>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <!-- Nếu đã đăng nhập -->
                        <a class="bg-[#003366] text-white px-4 py-1 rounded hover:bg-[#002244]" href="pages/account.php">
                            <div class="mobile-toger-home-intro-menu"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        </a>
                        <a class="bg-[#003366] text-white px-4 py-1 rounded hover:bg-[#002244]" href="pages/logout.php">
                            <div class="mobile-toger-home-intro-menu">Đăng xuất</div>
                        </a>
                    <?php else: ?>
                        <a href="pages/login.php" class="bg-[#003366] text-white px-4 py-1 rounded hover:bg-[#002244]">
                            Đăng nhập
                        </a>
                        <a href="pages/dangki.php" class="bg-[#003366] text-white px-4 py-1 rounded hover:bg-[#002244]">
                            Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>
    <!-- Main Content Container -->
    <main>