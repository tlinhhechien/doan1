<?php
// Chỉ khởi tạo session nếu chưa active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Thông tin kết nối database
$host = 'localhost';
$dbname = 'webbanve';
$username = 'root';
$password = ''; 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Kết nối thất bại: " . $e->getMessage());
}
?>